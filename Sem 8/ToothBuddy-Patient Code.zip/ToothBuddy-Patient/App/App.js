import React from "react";
import { StyleSheet } from "react-native";
import ImageUpload from "./Components/ImageUpload"; // Adjust the path if necessary
import Registration from "./Components/Registration";
import LoginPage from "./Components/LoginPage";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import HomePage from "./Components/HomePage";
// import { AuthProvider } from "./userContext";
import ProfileScreen from "./Components/ProfileScreen";
import ReportScreen from "./Components/ReportScreen";
import DemoReportScreen from "./Components/DemoReportScreen";
import ReportsScreen from "./Components/ReportsScreen";
import ReportDetailsScreen from "./Components/ReportDetailsScreen";
import DentistsListScreen from "./Components/DentistListScreen";
import ChatbotScreen from "./Components/ChatbotScreen";
import ChatsListScreen from "./Components/ChatsListScreen";
import ChatScreen from "./Components/ChatScreen";
import AppointmentScreen from "./Components/AppointmentScreen";

const Stack = createStackNavigator();

const App = () => {
  return (
    // <AuthProvider>
    <NavigationContainer>
      {/* <ImageUpload /> */}
      <Stack.Navigator initialRouteName="Register">
        <Stack.Screen
          name="Register"
          component={Registration}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Login"
          component={LoginPage}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Home"
          component={HomePage}
          options={{ headerShown: false }}
        />
        <Stack.Screen name="ImageUpload" component={ImageUpload} />
        <Stack.Screen
          name="Report"
          component={ReportScreen}
          options={{ title: "Detection Report" }}
        />
        <Stack.Screen
          name="ProfileScreen"
          component={ProfileScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="DemoReport"
          component={DemoReportScreen}
          options={{ title: "Demo Report" }}
        />
        <Stack.Screen
          name="Reports"
          component={ReportsScreen}
        />
        <Stack.Screen
          name="ReportDetails"
          component={ReportDetailsScreen}
        />
        <Stack.Screen
          name="Dentists"
          component={DentistsListScreen}
        />
        <Stack.Screen
          name="Chatbot"
          component={ChatbotScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ChatsListScreen"
          component={ChatsListScreen}
        />
        <Stack.Screen
          name="ChatScreen"
          component={ChatScreen}
        />
        <Stack.Screen
          name="AppointmentScreen"
          component={AppointmentScreen}
        />
        {/* Add Home Screen */}
      </Stack.Navigator>
    </NavigationContainer>
    // </AuthProvider>
  );
};
const style = StyleSheet.create({
  backg: {
    backgroundColor: "#1441f8", // Fix background color
    flex: 1, // Ensure full-screen coverage
    justifyContent: "center",
    alignItems: "center",
  },
});
export default App;
