// TopBar.js
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, Image } from "react-native";
import Icon from "react-native-vector-icons/FontAwesome"; // Import the icon library

const TopBar = ({ onProfilePress }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Toothbuddy</Text>
      <TouchableOpacity onPress={onProfilePress} style={styles.profileButton}>
        <Icon name="user" size={25} color="#fff" />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 70,
    backgroundColor: "#0288D1",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 15,
    position: "absolute",
    top: 45,
    zIndex: 2,
  },
  title: {
    fontSize: 20,
    color: "#fff",
    fontWeight: "bold",
  },
  profileButton: {
    padding: 5,
  },
  profileIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
  },
});

export default TopBar;
