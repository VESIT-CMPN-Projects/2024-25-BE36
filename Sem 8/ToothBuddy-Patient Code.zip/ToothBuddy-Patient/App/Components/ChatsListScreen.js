// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, query, where, getDocs } from "firebase/firestore";
// import { useNavigation } from "@react-navigation/native";
// import { MaterialIcons } from "@expo/vector-icons";

// const ChatsListScreen = () => {
//   const [userEmail, setUserEmail] = useState(null);
//   const [chats, setChats] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         setUserEmail(currentUser.email);
//         fetchChats(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return () => unsubscribe();
//   }, []);

//   const fetchChats = async (email) => {
//     if (!email) return;

//     try {
//       const chatsRef = collection(db, "chats");
//       const q = query(chatsRef, where("users", "array-contains", email));
//       const querySnapshot = await getDocs(q);

//       const chatList = querySnapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));

//       setChats(chatList);
//     } catch (error) {
//       console.error("Error fetching chats:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       <Text style={styles.heading}>💬 Your Chats</Text>

//       {chats.length > 0 ? (
//         <FlatList
//           data={chats}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity
//               style={styles.chatItem}
//               onPress={() => navigation.navigate("ChatScreen", { chatId: item.id })}
//             >
//               <MaterialIcons name="chat" size={24} color="#0288D1" />
//               <Text style={styles.chatText}>{item.chatName || "Unnamed Chat"}</Text>
//             </TouchableOpacity>
//           )}
//         />
//       ) : (
//         <Text style={styles.noChatsText}>No chats found.</Text>
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F5F5F5",
//     padding: 20,
//     alignItems: "center",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: 24,
//     fontWeight: "bold",
//     marginBottom: 15,
//     color: "#0288D1",
//   },
//   chatItem: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E3F2FD",
//     padding: 12,
//     marginVertical: 8,
//     borderRadius: 10,
//     width: "100%",
//   },
//   chatText: {
//     fontSize: 18,
//     marginLeft: 12,
//     color: "#333",
//     flexShrink: 1,
//   },
//   noChatsText: {
//     fontSize: 16,
//     color: "#888",
//     textAlign: "center",
//     marginTop: 20,
//   },
// });

// export default ChatsListScreen;




// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { collection, query, where, getDocs, addDoc, orderBy } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { useNavigation } from "@react-navigation/native";
// import { MaterialIcons } from "@expo/vector-icons";

// const ChatsListScreen = () => {
//   const [chats, setChats] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [user, setUser] = useState(null);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         setUser(currentUser);
//         fetchChats(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return unsubscribe;
//   }, []);

//   const fetchChats = async (email) => {
//     if (!email) return;

//     setLoading(true);
//     try {
//       console.log(`Fetching chats for: ${email}`);
//       const chatsRef = collection(db, "chats");
//       const q = query(chatsRef, where("users", "array-contains", email), orderBy("createdAt", "desc"));
//       const querySnapshot = await getDocs(q);

//       if (querySnapshot.empty) {
//         console.warn("No chats found for this user.");
//       }

//       const chatList = querySnapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));

//       setChats(chatList);
//     } catch (error) {
//       console.error("Error fetching chats:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const createNewChat = async () => {
//     if (!user) return;

//     try {
//       const chatRef = await addDoc(collection(db, "chats"), {
//         chatName: "New Chat",
//         users: [user.email], // Initially adding only the current user
//         createdAt: new Date(),
//       });

//       console.log("New chat created with ID:", chatRef.id);
//       fetchChats(user.email);
//     } catch (error) {
//       console.error("Error creating chat:", error);
//     }
//   };

//   const openChat = (chatId, chatName) => {
//     navigation.navigate("ChatScreen", { chatId, chatName });
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       <Text style={styles.heading}>💬 Your Chats</Text>

//       {chats.length === 0 ? (
//         <Text style={styles.noChatsText}>No chats available. Start a new conversation!</Text>
//       ) : (
//         <FlatList
//           data={chats}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item.id, item.chatName)}>
//               <MaterialIcons name="chat" size={24} color="#0288D1" />
//               <Text style={styles.chatText}>{item.chatName}</Text>
//             </TouchableOpacity>
//           )}
//         />
//       )}

//       <TouchableOpacity style={styles.newChatButton} onPress={createNewChat}>
//         <Text style={styles.newChatText}>+ Start New Chat</Text>
//       </TouchableOpacity>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F5F5F5",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: 26,
//     fontWeight: "bold",
//     color: "#0288D1",
//     textAlign: "center",
//     marginBottom: 15,
//   },
//   chatItem: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E3F2FD",
//     padding: 15,
//     borderRadius: 10,
//     marginBottom: 10,
//   },
//   chatText: {
//     fontSize: 18,
//     marginLeft: 10,
//     color: "#333",
//   },
//   noChatsText: {
//     fontSize: 18,
//     textAlign: "center",
//     color: "#888",
//     marginTop: 20,
//   },
//   newChatButton: {
//     marginTop: 20,
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 10,
//     alignItems: "center",
//   },
//   newChatText: {
//     color: "#FFF",
//     fontSize: 18,
//     fontWeight: "bold",
//   },
// });

// export default ChatsListScreen;





// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { collection, query, where, getDocs, addDoc, orderBy } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { useNavigation } from "@react-navigation/native";
// import { MaterialIcons } from "@expo/vector-icons";

// const ChatsListScreen = () => {
//   const [chats, setChats] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [userEmail, setUserEmail] = useState(null);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         setUserEmail(currentUser.email);
//         fetchChats(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return unsubscribe;
//   }, []);

//   const fetchChats = async (email) => {
//     if (!email) return;

//     setLoading(true);
//     try {
//       console.log(`Fetching chats for: ${email}`);
//       const chatsRef = collection(db, "chats");
//       const q = query(chatsRef, where("users", "array-contains", email));
//       const querySnapshot = await getDocs(q);

//       const chatList = querySnapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));

//       setChats(chatList);
//     } catch (error) {
//       console.error("Error fetching chats:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const createNewChat = async () => {
//     if (!userEmail) return;

//     try {
//       const chatRef = await addDoc(collection(db, "chats"), {
//         chatName: "New Chat",
//         users: [userEmail],
//         createdAt: new Date(),
//       });

//       console.log("New chat created with ID:", chatRef.id);
//       fetchChats(userEmail);
//     } catch (error) {
//       console.error("Error creating chat:", error);
//     }
//   };

//   const openChat = (chatId, chatName) => {
//     navigation.navigate("ChatScreen", { chatId, chatName });
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       <Text style={styles.heading}>💬 Your Chats</Text>

//       {chats.length === 0 ? (
//         <Text style={styles.noChatsText}>No chats available. Start a new conversation!</Text>
//       ) : (
//         <FlatList
//           data={chats}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item.id, item.chatName)}>
//               <MaterialIcons name="chat" size={24} color="#0288D1" />
//               <Text style={styles.chatText}>{item.chatName}</Text>
//             </TouchableOpacity>
//           )}
//         />
//       )}

//       <TouchableOpacity style={styles.newChatButton} onPress={createNewChat}>
//         <Text style={styles.newChatText}>+ Start New Chat</Text>
//       </TouchableOpacity>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F5F5F5",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: 26,
//     fontWeight: "bold",
//     color: "#0288D1",
//     textAlign: "center",
//     marginBottom: 15,
//   },
//   chatItem: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E3F2FD",
//     padding: 15,
//     borderRadius: 10,
//     marginBottom: 10,
//   },
//   chatText: {
//     fontSize: 18,
//     marginLeft: 10,
//     color: "#333",
//   },
//   noChatsText: {
//     fontSize: 18,
//     textAlign: "center",
//     color: "#888",
//     marginTop: 20,
//   },
//   newChatButton: {
//     marginTop: 20,
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 10,
//     alignItems: "center",
//   },
//   newChatText: {
//     color: "#FFF",
//     fontSize: 18,
//     fontWeight: "bold",
//   },
// });

// export default ChatsListScreen;




// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { collection, query, where, getDocs, addDoc, orderBy } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { useNavigation } from "@react-navigation/native";
// import { MaterialIcons } from "@expo/vector-icons";

// const ChatsListScreen = () => {
//   const [chats, setChats] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [user, setUser] = useState(null);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         setUser(currentUser);
//         fetchChats(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return unsubscribe;
//   }, []);
//   const fetchChats = async (email) => {
//     if (!email) return;
  
//     setLoading(true);
//     try {
//       console.log(`Fetching chats for: ${email}`);
      
//       const chatsRef = collection(db, "chats");
//       const q = query(
//         chatsRef,
//         where("user1", "==", email)
//       );
//       const querySnapshot = await getDocs(q);
  
//       if (querySnapshot.empty) {
//         console.warn("No chats found for this user.");
//       } else {
//         console.log("Chats found:", querySnapshot.docs.map(doc => doc.data()));
//       }
  
//       const chatList = querySnapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
  
//       setChats(chatList);
//     } catch (error) {
//       console.error("Error fetching chats:", error);
//     } finally {
//       setLoading(false);
//     }
//   };
//   const openChat = (chatId, chatName) => {
//     navigation.navigate("ChatScreen", { chatId, chatName });
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       <Text style={styles.heading}>💬 Your Chats</Text>

//       {chats.length === 0 ? (
//         <Text style={styles.noChatsText}>No chats available. Start a new conversation!</Text>
//       ) : (
//         <FlatList
//           data={chats}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item.id, item.chatName)}>
//               <MaterialIcons name="chat" size={24} color="#0288D1" />
//               <Text style={styles.chatText}>{item.chatName}</Text>
//             </TouchableOpacity>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F5F5F5",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: 26,
//     fontWeight: "bold",
//     color: "#0288D1",
//     textAlign: "center",
//     marginBottom: 15,
//   },
//   chatItem: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#E3F2FD",
//     padding: 15,
//     borderRadius: 10,
//     marginBottom: 10,
//   },
//   chatText: {
//     fontSize: 18,
//     marginLeft: 10,
//     color: "#333",
//   },
//   noChatsText: {
//     fontSize: 18,
//     textAlign: "center",
//     color: "#888",
//     marginTop: 20,
//   },
// });

// export default ChatsListScreen;




import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
import { collection, query, where, getDocs } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { useNavigation } from "@react-navigation/native";
import { MaterialIcons } from "@expo/vector-icons";

const ChatsListScreen = () => {
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        fetchChats(currentUser.email);
      } else {
        setLoading(false);
      }
    });
    return unsubscribe;
  }, []);

  const fetchChats = async (email) => {
    if (!email) return;
    setLoading(true);
    try {
      console.log(`Fetching chats for: ${email}`);
      
      const chatsRef = collection(db, "chats");
      const q = query(
        chatsRef,
        where("user1", "==", email)
      );
      const querySnapshot = await getDocs(q);
  
      if (querySnapshot.empty) {
        console.warn("No chats found for this user.");
      } else {
        console.log("Chats found:", querySnapshot.docs.map(doc => doc.data()));
      }
  
      const chatList = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        user2: doc.data().user2, // Fetch user2 name
        ...doc.data(),
      }));
  
      setChats(chatList);
    } catch (error) {
      console.error("Error fetching chats:", error);
    } finally {
      setLoading(false);
    }
  };

  const openChat = (chatId) => {
    navigation.navigate("ChatScreen", { chatId });
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>💬 Your Chats</Text>

      {chats.length === 0 ? (
        <Text style={styles.noChatsText}>No chats available. Start a new conversation!</Text>
      ) : (
        <FlatList
          data={chats}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item.id)}>
              <MaterialIcons name="chat" size={24} color="#0288D1" />
              <Text style={styles.chatText}>{item.user2}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#F5F5F5",
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#0288D1",
    textAlign: "center",
    marginBottom: 15,
  },
  chatItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#E3F2FD",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  chatText: {
    fontSize: 18,
    marginLeft: 10,
    color: "#333",
  },
  noChatsText: {
    fontSize: 18,
    textAlign: "center",
    color: "#888",
    marginTop: 20,
  },
});

export default ChatsListScreen;
