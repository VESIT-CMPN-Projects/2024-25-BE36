// DentistrySpecialistsScroller.js
import React from "react";
import {
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";

const DentistrySpecialistsScroller = ({ specialists, onPressItem }) => {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={true}
      style={styles.scrollContainer}
    >
      {specialists.map((item, index) => (
        <TouchableOpacity
          key={index}
          onPress={() => onPressItem(item)}
          style={styles.card}
        >
          <ImageBackground
            source={{ uri: item.image }}
            style={styles.imageBackground}
            imageStyle={{ borderRadius: 10 }}
          >
            <View style={styles.overlay}>
              <Text style={styles.text}>{item.name}</Text>
            </View>
          </ImageBackground>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    width: "100%",
    marginVertical: 10,
  },
  card: {
    width: 350,
    height: 150,
    borderRadius: 10,
    overflow: "hidden",
    marginRight: 15,
  },
  imageBackground: {
    width: "100%",
    height: "100%",
    justifyContent: "flex-end",
  },
  overlay: {
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    padding: 5,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  text: {
    color: "white",
    fontSize: 14,
    fontWeight: "bold",
    textAlign: "center",
  },
});

export default DentistrySpecialistsScroller;
