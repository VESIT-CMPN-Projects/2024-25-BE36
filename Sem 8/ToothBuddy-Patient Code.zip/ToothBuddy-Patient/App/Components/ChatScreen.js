// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { doctorEmail, userEmail } = route.params;
//   const auth = getAuth();
//   const currentUser = auth.currentUser;

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   // Generate a unique chat ID based on user and doctor emails
//   const chatId =
//     userEmail < doctorEmail
//       ? `${userEmail}_${doctorEmail}`
//       : `${doctorEmail}_${userEmail}`;

//   useEffect(() => {
//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (snapshot) => {
//       const loadedMessages = snapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
//       setMessages(loadedMessages);
//     });

//     return () => unsubscribe(); // Cleanup on unmount
//   }, [chatId]);

//   const sendMessage = async () => {
//     if (inputText.trim() === "") return;

//     try {
//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });
//       setInputText(""); // Clear input after sending
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       {/* Chat Messages */}
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text style={styles.messageText}>{item.text}</Text>
//           </View>
//         )}
//       />

//       {/* Input Field & Send Button */}
//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={(text) => setInputText(text)}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA",
//   },
//   messageContainer: {
//     padding: 10,
//     marginVertical: 5,
//     marginHorizontal: 10,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: {
//     alignSelf: "flex-end",
//     backgroundColor: "#007BFF",
//   },
//   otherMessage: {
//     alignSelf: "flex-start",
//     backgroundColor: "#E0E0E0",
//   },
//   messageText: {
//     fontSize: 16,
//     color: "#fff",
//   },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     backgroundColor: "#fff",
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//     backgroundColor: "#fff",
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   sendButtonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
// });

// export default ChatScreen;

// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
//   doc,
//   setDoc,
//   getDoc,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { doctorEmail, userEmail } = route.params;
//   const auth = getAuth();
//   const currentUser = auth.currentUser;

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   // Generate a unique chat ID based on user and doctor emails
//   const chatId =
//     userEmail < doctorEmail
//       ? `${userEmail}_${doctorEmail}`
//       : `${doctorEmail}_${userEmail}`;

//   useEffect(() => {
//     if (!currentUser) return; // Prevent error if auth hasn't loaded

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (snapshot) => {
//       const loadedMessages = snapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
//       setMessages(loadedMessages);
//     });

//     return () => unsubscribe(); // Cleanup on unmount
//   }, [chatId, currentUser]);

//   const ensureChatExists = async () => {
//     const chatRef = doc(db, "chats", chatId);
//     const chatDoc = await getDoc(chatRef);

//     if (!chatDoc.exists()) {
//       await setDoc(chatRef, {
//         user1: userEmail,
//         user2: doctorEmail,
//         lastMessage: "",
//         timestamp: serverTimestamp(),
//       });
//     }
//   };

//   const sendMessage = async () => {
//     if (!currentUser || inputText.trim() === "") return;

//     try {
//       await ensureChatExists(); // Ensure chat document exists before adding messages

//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });

//       setInputText(""); // Clear input after sending
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       {/* Chat Messages */}
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser?.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text
//               style={[
//                 styles.messageText,
//                 item.sender !== currentUser?.email && styles.otherMessageText,
//               ]}
//             >
//               {item.text}
//             </Text>
//           </View>
//         )}
//       />

//       {/* Input Field & Send Button */}
//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={(text) => setInputText(text)}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA",
//   },
//   messageContainer: {
//     padding: 10,
//     marginVertical: 5,
//     marginHorizontal: 10,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: {
//     alignSelf: "flex-end",
//     backgroundColor: "#007BFF",
//   },
//   otherMessage: {
//     alignSelf: "flex-start",
//     backgroundColor: "#E0E0E0",
//   },
//   messageText: {
//     fontSize: 16,
//     color: "#fff",
//   },
//   otherMessageText: {
//     color: "#000", // Black text for better contrast on light background
//   },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     backgroundColor: "#fff",
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//     backgroundColor: "#fff",
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   sendButtonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
// });

// export default ChatScreen;

// import React, { useState, useEffect, useMemo, useRef } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
//   doc,
//   setDoc,
//   getDoc,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { doctorEmail, userEmail } = route.params;
//   const auth = getAuth();
//   const currentUser = auth.currentUser;
//   const flatListRef = useRef(null);

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   // Memoized Chat ID to prevent unnecessary recomputations
//   const chatId = useMemo(
//     () =>
//       userEmail < doctorEmail
//         ? `${userEmail}_${doctorEmail}`
//         : `${doctorEmail}_${userEmail}`,
//     [userEmail, doctorEmail]
//   );

//   useEffect(() => {
//     if (!currentUser) return;

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(
//       q,
//       (snapshot) => {
//         const loadedMessages = snapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));
//         setMessages(loadedMessages);
//         flatListRef.current?.scrollToEnd({ animated: true });
//       },
//       (error) => console.error("Error fetching messages:", error)
//     );

//     return () => unsubscribe();
//   }, [chatId, currentUser]);

//   const ensureChatExists = async () => {
//     try {
//       const chatRef = doc(db, "chats", chatId);
//       const chatDoc = await getDoc(chatRef);

//       if (!chatDoc.exists()) {
//         await setDoc(chatRef, {
//           user1: userEmail,
//           user2: doctorEmail,
//           lastMessage: "",
//           timestamp: serverTimestamp(),
//         });
//       }
//     } catch (error) {
//       console.error("Error ensuring chat exists:", error);
//     }
//   };

//   const sendMessage = async () => {
//     if (!currentUser || inputText.trim() === "") return;

//     try {
//       await ensureChatExists();
//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText.trim(),
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });

//       setInputText("");
//       flatListRef.current?.scrollToEnd({ animated: true });
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       {/* Chat Messages */}
//       <FlatList
//         ref={flatListRef}
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser?.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text
//               style={[
//                 styles.messageText,
//                 item.sender !== currentUser?.email && styles.otherMessageText,
//               ]}
//             >
//               {item.text}
//             </Text>
//           </View>
//         )}
//         onContentSizeChange={() =>
//           flatListRef.current?.scrollToEnd({ animated: true })
//         }
//       />

//       {/* Input Field & Send Button */}
//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={setInputText}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA",
//   },
//   messageContainer: {
//     padding: 10,
//     marginVertical: 5,
//     marginHorizontal: 10,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: {
//     alignSelf: "flex-end",
//     backgroundColor: "#007BFF",
//   },
//   otherMessage: {
//     alignSelf: "flex-start",
//     backgroundColor: "#E0E0E0",
//   },
//   messageText: {
//     fontSize: 16,
//     color: "#fff",
//   },
//   otherMessageText: {
//     color: "#000",
//   },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     backgroundColor: "#fff",
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//     backgroundColor: "#fff",
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   sendButtonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
// });

// export default ChatScreen;

// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
//   doc,
//   setDoc,
//   getDoc,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { doctorEmail, userEmail } = route.params || {}; // Ensure route params are not undefined
//   const auth = getAuth();
//   const currentUser = auth.currentUser;

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   // Debugging logs
//   console.log("Route Params:", route.params);
//   console.log("Current User:", currentUser?.email);

//   if (!doctorEmail || !userEmail) {
//     console.error("Missing doctorEmail or userEmail in route params!");
//     return (
//       <View style={styles.errorContainer}>
//         <Text>Error: Invalid Chat</Text>
//       </View>
//     );
//   }

//   // Generate unique chat ID
//   const chatId =
//     userEmail < doctorEmail
//       ? `${userEmail}_${doctorEmail}`
//       : `${doctorEmail}_${userEmail}`;

//   useEffect(() => {
//     if (!currentUser) return;

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (snapshot) => {
//       if (!snapshot.empty) {
//         const loadedMessages = snapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));
//         setMessages(loadedMessages);
//       } else {
//         console.log("No previous messages found.");
//       }
//     });

//     return () => unsubscribe();
//   }, [chatId, currentUser]);

//   const ensureChatExists = async () => {
//     try {
//       const chatRef = doc(db, "chats", chatId);
//       const chatDoc = await getDoc(chatRef);

//       if (!chatDoc.exists()) {
//         await setDoc(chatRef, {
//           user1: userEmail,
//           user2: doctorEmail,
//           lastMessage: "",
//           timestamp: serverTimestamp(),
//         });
//       }
//     } catch (error) {
//       console.error("Error ensuring chat exists:", error);
//     }
//   };

//   const sendMessage = async () => {
//     if (!currentUser || inputText.trim() === "") return;

//     try {
//       await ensureChatExists();

//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });

//       setInputText("");
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser?.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text
//               style={[
//                 styles.messageText,
//                 item.sender !== currentUser?.email && styles.otherMessageText,
//               ]}
//             >
//               {item.text}
//             </Text>
//           </View>
//         )}
//       />

//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={(text) => setInputText(text)}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA",
//   },
//   errorContainer: {
//     flex: 1,
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   messageContainer: {
//     padding: 10,
//     marginVertical: 5,
//     marginHorizontal: 10,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: {
//     alignSelf: "flex-end",
//     backgroundColor: "#007BFF",
//   },
//   otherMessage: {
//     alignSelf: "flex-start",
//     backgroundColor: "#E0E0E0",
//   },
//   messageText: {
//     fontSize: 16,
//     color: "#fff",
//   },
//   otherMessageText: {
//     color: "#000",
//   },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     backgroundColor: "#fff",
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//     backgroundColor: "#fff",
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//     alignItems: "center",
//     justifyContent: "center",
//   },
//   sendButtonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
// });

// export default ChatScreen;

// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
//   doc,
//   setDoc,
//   getDoc,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { doctorEmail, userEmail } = route.params || {};
//   const auth = getAuth();
//   const currentUser = auth.currentUser;

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   if (!doctorEmail || !userEmail) {
//     console.error("Missing doctorEmail or userEmail in route params!");
//     return (
//       <View style={styles.errorContainer}>
//         <Text>Error: Invalid Chat</Text>
//       </View>
//     );
//   }

//   const chatId =
//     userEmail < doctorEmail
//       ? `${userEmail}_${doctorEmail}`
//       : `${doctorEmail}_${userEmail}`;

//   useEffect(() => {
//     if (!currentUser) return;

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (snapshot) => {
//       const loadedMessages = snapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
//       setMessages(loadedMessages);
//     });

//     return () => unsubscribe();
//   }, [chatId, currentUser]);

//   const ensureChatExists = async () => {
//     try {
//       const chatRef = doc(db, "chats", chatId);
//       const chatDoc = await getDoc(chatRef);

//       if (!chatDoc.exists()) {
//         await setDoc(chatRef, {
//           user1: userEmail,
//           user2: doctorEmail,
//           lastMessage: "",
//           timestamp: serverTimestamp(),
//         });
//       }
//     } catch (error) {
//       console.error("Error ensuring chat exists:", error);
//     }
//   };

//   const sendMessage = async () => {
//     if (!currentUser || inputText.trim() === "") return;

//     try {
//       await ensureChatExists();

//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });
//       setInputText("");
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser?.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text style={styles.messageText}>{item.text}</Text>
//           </View>
//         )}
//       />

//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={setInputText}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: "#F8F9FA" },
//   errorContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
//   messageContainer: {
//     padding: 10,
//     margin: 5,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: { alignSelf: "flex-end", backgroundColor: "#007BFF" },
//   otherMessage: { alignSelf: "flex-start", backgroundColor: "#E0E0E0" },
//   messageText: { fontSize: 16, color: "#fff" },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//   },
//   sendButtonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
// });

// export default ChatScreen;



// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   KeyboardAvoidingView,
//   Platform,
//   StyleSheet,
// } from "react-native";
// import {
//   collection,
//   query,
//   orderBy,
//   addDoc,
//   onSnapshot,
//   serverTimestamp,
//   doc,
//   setDoc,
//   getDoc,
// } from "firebase/firestore";
// import { db } from "../firebaseConfig";
// import { getAuth } from "firebase/auth";

// const ChatScreen = ({ route }) => {
//   const { chatId} = route.params || {};
//   const auth = getAuth();
//   const currentUser = auth.currentUser;

//   const [messages, setMessages] = useState([]);
//   const [inputText, setInputText] = useState("");

//   if (!doctorEmail || !userEmail) {
//     console.error("Missing doctorEmail or userEmail in route params!");
//     return (
//       <View style={styles.errorContainer}>
//         <Text>Error: Invalid Chat</Text>
//       </View>
//     );
//   }

//   // Ensure chatId is either passed or derived correctly
//   const chatId =
//     passedChatId ||
//     (userEmail < doctorEmail
//       ? `${userEmail}_${doctorEmail}`
//       : `${doctorEmail}_${userEmail}`);

//   useEffect(() => {
//     if (!currentUser) return;

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (snapshot) => {
//       const loadedMessages = snapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
//       console.log("Fetched messages:", loadedMessages); // Debugging logs
//       setMessages(loadedMessages);
//     });

//     return () => unsubscribe();
//   }, [chatId, currentUser]);

//   const ensureChatExists = async () => {
//     try {
//       const chatRef = doc(db, "chats", chatId);
//       const chatDoc = await getDoc(chatRef);

//       if (!chatDoc.exists()) {
//         await setDoc(chatRef, {
//           user1: userEmail,
//           user2: doctorEmail,
//           lastMessage: "",
//           timestamp: serverTimestamp(),
//         });
//       }
//     } catch (error) {
//       console.error("Error ensuring chat exists:", error);
//     }
//   };

//   const sendMessage = async () => {
//     if (!currentUser || inputText.trim() === "") return;

//     try {
//       await ensureChatExists();

//       await addDoc(collection(db, "chats", chatId, "messages"), {
//         text: inputText,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });
//       setInputText("");
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === "ios" ? "padding" : "height"}
//     >
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageContainer,
//               item.sender === currentUser?.email
//                 ? styles.myMessage
//                 : styles.otherMessage,
//             ]}
//           >
//             <Text style={styles.messageText}>{item.text}</Text>
//           </View>
//         )}
//       />

//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={inputText}
//           onChangeText={setInputText}
//         />
//         <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
//           <Text style={styles.sendButtonText}>Send</Text>
//         </TouchableOpacity>
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: "#F8F9FA" },
//   errorContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
//   messageContainer: {
//     padding: 10,
//     margin: 5,
//     borderRadius: 8,
//     maxWidth: "75%",
//   },
//   myMessage: { alignSelf: "flex-end", backgroundColor: "#007BFF" },
//   otherMessage: { alignSelf: "flex-start", backgroundColor: "#E0E0E0" },
//   messageText: { fontSize: 16, color: "#fff" },
//   inputContainer: {
//     flexDirection: "row",
//     padding: 10,
//     borderTopWidth: 1,
//     borderColor: "#ddd",
//   },
//   input: {
//     flex: 1,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//   },
//   sendButton: {
//     marginLeft: 10,
//     backgroundColor: "#007BFF",
//     padding: 10,
//     borderRadius: 8,
//   },
//   sendButtonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
// });

// export default ChatScreen;

// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";
// import { useRoute } from "@react-navigation/native";
// import { MaterialIcons } from "@expo/vector-icons";
// import { Linking } from "react-native";

// const ChatScreen = () => {
//   const route = useRoute();
//   const { chatId } = route.params;  // Get chatId from navigation
//   const [messages, setMessages] = useState([]);
//   const [newMessage, setNewMessage] = useState("");
//   const [loading, setLoading] = useState(true);
//   const currentUser = auth.currentUser;

//   useEffect(() => {
//     if (!chatId) return;

//     const messagesRef = collection(db, "chats", chatId, "messages");
//     const q = query(messagesRef, orderBy("timestamp", "asc"));

//     const unsubscribe = onSnapshot(q, (querySnapshot) => {
//       const msgs = querySnapshot.docs.map((doc) => ({
//         id: doc.id,
//         ...doc.data(),
//       }));
//       setMessages(msgs);
//       setLoading(false);
//     });

//     return () => unsubscribe();
//   }, [chatId]);

//   const sendMessage = async () => {
//     if (newMessage.trim() === "") return;

//     try {
//       const messagesRef = collection(db, "chats", chatId, "messages");
//       await addDoc(messagesRef, {
//         text: newMessage,
//         sender: currentUser.email,
//         timestamp: serverTimestamp(),
//       });

//       setNewMessage("");
//     } catch (error) {
//       console.error("Error sending message:", error);
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }
//   const renderItem = ({ item }) => {
//     const isLink = item.text.startsWith("https");
//     return (
//       <View style={[styles.messageBubble, item.sender === currentUser.email ? styles.sentMessage : styles.receivedMessage]}>
//         {isLink ? (
//           <Text style={[styles.messageText, { textDecorationLine: "underline", color: "#87CEEB" }]} onPress={() => Linking.openURL(item.text)}>
//             {item.text}
//           </Text>
//         ) : (
//           <Text style={styles.messageText}>{item.text}</Text>
//         )}
//       </View>
//     );
//   };
//   return (
//     <View style={styles.container}>
//       <FlatList
//     data={messages}
//     keyExtractor={(item) => item.id}
//     renderItem={renderItem}
//   />

//       {/* Message Input */}
//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type a message..."
//           value={newMessage}
//           onChangeText={setNewMessage}
//         />
//         <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
//           <MaterialIcons name="send" size={24} color="#fff" />
//         </TouchableOpacity>
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F5F5F5",
//     padding: 10,
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   messageBubble: {
//     padding: 10,
//     borderRadius: 10,
//     marginVertical: 5,
//     maxWidth: "75%",
//   },
//   sentMessage: {
//     alignSelf: "flex-end",
//     backgroundColor: "rgb(5, 84, 204)",
//   },
//   receivedMessage: {
//     alignSelf: "flex-start",
//     backgroundColor: "rgb(4, 35, 83)",
//   },
//   messageText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   inputContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     padding: 10,
//     borderTopWidth: 1,
//     borderColor: "#ccc",
//     backgroundColor: "#fff",
//   },
//   input: {
//     flex: 1,
//     padding: 10,
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 25,
//     marginRight: 10,
//   },
//   sendButton: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 50,
//   },
// });

// export default ChatScreen;
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
} from "react-native";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { useRoute } from "@react-navigation/native";
import { MaterialIcons } from "@expo/vector-icons";
import { Linking } from "react-native";

const ChatScreen = () => {
  const route = useRoute();
  const { chatId } = route.params;
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const currentUser = auth.currentUser;

  useEffect(() => {
    if (!chatId) return;

    const messagesRef = collection(db, "chats", chatId, "messages");
    const q = query(messagesRef, orderBy("timestamp", "asc"));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const msgs = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setMessages(msgs);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [chatId]);

  const sendMessage = async () => {
    if (newMessage.trim() === "") return;

    try {
      const messagesRef = collection(db, "chats", chatId, "messages");
      await addDoc(messagesRef, {
        text: newMessage,
        sender: currentUser.email,
        timestamp: serverTimestamp(),
      });

      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  const renderItem = ({ item }) => {
    const isLink = item.text.startsWith("https");
    return (
      <View
        style={[
          styles.messageBubble,
          item.sender === currentUser.email
            ? styles.sentMessage
            : styles.receivedMessage,
        ]}
      >
        {isLink ? (
          <Text
            style={[
              styles.messageText,
              { textDecorationLine: "underline", color: "#87CEEB" },
            ]}
            onPress={() => Linking.openURL(item.text)}
          >
            {item.text}
          </Text>
        ) : (
          <Text style={styles.messageText}>{item.text}</Text>
        )}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 95}
      style={styles.container}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.innerContainer}>
          <FlatList data={messages} keyExtractor={(item) => item.id} renderItem={renderItem} />

          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Type a message..."
              value={newMessage}
              onChangeText={setNewMessage}
            />
            <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
              <MaterialIcons name="send" size={24} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  innerContainer: {
    flex: 1,
    backgroundColor: "#F5F5F5",
    padding: 10,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  messageBubble: {
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
    maxWidth: "75%",
  },
  sentMessage: {
    alignSelf: "flex-end",
    backgroundColor: "rgb(5, 84, 204)",
  },
  receivedMessage: {
    alignSelf: "flex-start",
    backgroundColor: "rgb(4, 35, 83)",
  },
  messageText: {
    color: "#fff",
    fontSize: 16,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderTopWidth: 1,
    borderColor: "#ccc",
    backgroundColor: "#fff",
  },
  input: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 25,
    marginRight: 10,
  },
  sendButton: {
    backgroundColor: "#0288D1",
    padding: 10,
    borderRadius: 50,
  },
});

export default ChatScreen;