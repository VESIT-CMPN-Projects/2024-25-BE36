// import React from "react";
// import { View, Text, StyleSheet, ScrollView } from "react-native";

// const ReportDetailsScreen = ({ route }) => {
//   const { report } = route.params; // Get the report details from navigation

//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       <Text style={styles.heading}>📝 Report Details</Text>
//       <Text style={styles.date}>📅 Date: {report.date}</Text>

//       <View style={styles.reportSection}>
//         <Text style={styles.sectionTitle}>Findings:</Text>
//         <Text style={styles.text}>{report.findings || "No findings available"}</Text>
//       </View>

//       <View style={styles.reportSection}>
//         <Text style={styles.sectionTitle}>Diagnosis:</Text>
//         <Text style={styles.text}>{report.diagnosis || "No diagnosis provided"}</Text>
//       </View>

//       <View style={styles.reportSection}>
//         <Text style={styles.sectionTitle}>Suggestions:</Text>
//         <Text style={styles.text}>{report.suggestions || "No suggestions provided"}</Text>
//       </View>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flexGrow: 1, padding: 20, backgroundColor: "#F5F5F5" },
//   heading: { fontSize: 26, fontWeight: "bold", textAlign: "center", marginBottom: 15, color: "#0288D1" },
//   date: { fontSize: 18, fontWeight: "bold", marginBottom: 10, color: "#555" },
//   reportSection: { marginBottom: 15, backgroundColor: "#E3F2FD", padding: 10, borderRadius: 8 },
//   sectionTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 5, color: "#0288D1" },
//   text: { fontSize: 18, color: "#333" },
// });

// export default ReportDetailsScreen;
import React from "react";
import { View, Text, Image, StyleSheet, ScrollView } from "react-native";

const ReportDetailsScreen = ({ route }) => {
  const { report } = route.params;

  const classMapping = {
    "1": "Ulcer",
    "2": "Tooth Discoloration",
    "3": "Gingivitis",
    "caries": "Caries",
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Report Details</Text>

      <View style={styles.reportInfo}>
        <Text style={styles.reportText}>📅 {report.date}</Text>
      </View>

      <Image source={{ uri: report.imageUrl }} style={styles.image} />

      <View style={styles.reportContainer}>
        <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
        {report.detections.length > 0 ? (
          report.detections.map((det, index) => {
            const condition = classMapping[det.class] || "Unknown Condition";
            return ( // Return is necessary inside map
              <Text key={index} style={styles.detectionText}>
                🦷 {condition} (Confidence: {(det.confidence * 100).toFixed(2)}%)
              </Text>
            );
          })
        ) : (
          <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#F9FAFB",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
    color: "#0288D1",
  },
  reportInfo: {
    backgroundColor: "#E3F2FD",
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: "center",
  },
  reportText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#01579B",
    marginBottom: 5,
  },
  image: {
    width: "100%",
    height: 250,
    borderRadius: 10,
    marginBottom: 20,
  },
  reportContainer: {
    padding: 15,
    backgroundColor: "#E3F2FD",
    borderRadius: 10,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#01579B",
  },
  detectionText: {
    fontSize: 16,
    marginTop: 5,
    color: "#333",
  },
  noDetectionText: {
    fontSize: 16,
    color: "green",
    fontWeight: "bold",
    marginTop: 5,
  },
});

export default ReportDetailsScreen;
