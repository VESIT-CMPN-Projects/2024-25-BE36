// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { collection, getDocs } from "firebase/firestore";
// import { useNavigation } from "@react-navigation/native";

// const ReportsScreen = () => {
//   const [reports, setReports] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const fetchReports = async () => {
//       setLoading(true);
//       try {
//         const user = auth.currentUser;
//         if (!user) return;

//         const reportsRef = collection(db, "users", user.uid, "reports");
//         const reportsSnapshot = await getDocs(reportsRef);

//         const reportsList = reportsSnapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));

//         setReports(reportsList);
//       } catch (error) {
//         console.error("Error fetching reports:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchReports();
//   }, []);

//   if (loading) {
//     return <ActivityIndicator size="large" color="#0288D1" />;
//   }

//   return (
//     <View style={styles.container}>
//       <Text style={styles.heading}>📋 Saved Reports</Text>
//       <FlatList
//         data={reports}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <TouchableOpacity
//             style={styles.reportItem}
//             onPress={() => navigation.navigate("ReportDetails", { report: item })}
//           >
//             <Text style={styles.reportTitle}>{item.title || "Report"}</Text>
//           </TouchableOpacity>
//         )}
//       />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//     container: { 
//       flex: 1, 
//       padding: 20, 
//       backgroundColor: "#F9FAFC", // Lighter background for a clean look
//     },
//     heading: { 
//       fontSize: 26, 
//       fontWeight: "bold", 
//       textAlign: "center", 
//       marginBottom: 20, 
//       color: "#0277BD", // Darker blue for better contrast
//     },
//     reportItem: { 
//       backgroundColor: "#E3F2FD", 
//       padding: 16, 
//       marginVertical: 10, 
//       borderRadius: 12, 
//       shadowColor: "#000", 
//       shadowOffset: { width: 0, height: 2 }, 
//       shadowOpacity: 0.1, 
//       shadowRadius: 5, 
//       elevation: 3, // For Android shadow
//       flexDirection: "row", 
//       alignItems: "center", 
//       borderLeftWidth: 5, 
//       borderLeftColor: "#0288D1", // Adds a color accent
//     },
//     reportTitle: { 
//       fontSize: 18, 
//       color: "#333", 
//       fontWeight: "500", 
//       flexShrink: 1, // Prevents text overflow issues
//     },
//   });
  

// export default ReportsScreen;


import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
import { collection, getDocs } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { useNavigation } from "@react-navigation/native";

const ReportsScreen = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const userId = auth.currentUser?.uid;
        if (!userId) return;

        const reportsRef = collection(db, "users", userId, "reports");
        const querySnapshot = await getDocs(reportsRef);
        
        const reportsList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));

        setReports(reportsList);
      } catch (error) {
        console.error("Error fetching reports:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, []);

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your Reports</Text>
      {reports.length === 0 ? (
        <Text style={styles.noReports}>No reports found.</Text>
      ) : (
        <FlatList
          data={reports}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.reportItem}
              onPress={() => navigation.navigate("ReportDetails", { report: item })}
            >
              <Text style={styles.reportTitle}>📋 Report:- {item.date}</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#F9FAFB",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
    color: "#0288D1",
  },
  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  noReports: {
    textAlign: "center",
    fontSize: 16,
    color: "gray",
  },
  reportItem: {
    padding: 15,
    backgroundColor: "#E3F2FD",
    borderRadius: 10,
    marginBottom: 10,
  },
  reportTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#01579B",
  },
});

export default ReportsScreen;

