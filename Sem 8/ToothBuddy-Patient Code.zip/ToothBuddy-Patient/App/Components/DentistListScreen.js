// import React, { useEffect, useState } from "react";
// import {
//   View,
//   Text,
//   FlatList,
//   TouchableOpacity,
//   Image,
//   StyleSheet,
//   ActivityIndicator,
// } from "react-native";
// import { collection, getDocs } from "firebase/firestore";
// import { db } from "../firebaseConfig"; // Ensure your Firebase is properly configured
// import { useNavigation } from "@react-navigation/native";

// const DentistsListScreen = () => {
//   const [dentists, setDentists] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const fetchDentists = async () => {
//       try {
//         const dentistsRef = collection(db, "dentists");
//         const querySnapshot = await getDocs(dentistsRef);

//         const dentistsList = querySnapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));

//         setDentists(dentistsList);
//       } catch (error) {
//         console.error("Error fetching dentists:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchDentists();
//   }, []);

//   if (loading) {
//     return (
//       <View style={styles.loader}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       {dentists.length === 0 ? (
//         <Text style={styles.noDentists}>No dentists found.</Text>
//       ) : (
//         <FlatList
//           data={dentists}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <View style={styles.card}>
//               <Image source={{ uri: item.imageUrl }} style={styles.image} />
//               <View style={styles.details}>
//                 <Text style={styles.name}>{item.name}</Text>
//                 <Text style={styles.specialization}>{item.specialization}</Text>
//                 <Text style={styles.text}>📧 {item.email}</Text>
//                 <Text style={styles.text}>📍 {item.location}</Text>
//                 <Text style={styles.text}>📞 {item.phone}</Text>
//                 <Text style={styles.text}>
//                   🩺 {item.experience} years experience
//                 </Text>
//                 <Text style={styles.text}>🕒 Available: {item.time}</Text>

//                 <View style={styles.buttonContainer}>
//                   <TouchableOpacity
//                     style={styles.bookButton}
//                     onPress={() =>
//                       navigation.navigate("BookAppointmentScreen", {
//                         doctorId: item.id,
//                       })
//                     }
//                   >
//                     <Text style={styles.buttonText}>Book Appointment</Text>
//                   </TouchableOpacity>

//                   <TouchableOpacity
//                     style={styles.consultButton}
//                     onPress={() =>
//                       navigation.navigate("ConsultOnlineScreen", {
//                         doctorId: item.id,
//                       })
//                     }
//                   >
//                     <Text style={styles.buttonText}>Consult Online</Text>
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             </View>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA", // Light gray background for contrast
//     padding: 10,
//   },
//   card: {
//     flexDirection: "row",
//     backgroundColor: "#fff",
//     borderRadius: 12,
//     padding: 15,
//     marginVertical: 10,
//     marginHorizontal: 20,
//     shadowColor: "#000",
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, height: 2 },
//     shadowRadius: 4,
//     elevation: 4, // Adds a slight lift effect
//     alignItems: "center",
//     borderWidth: 1,
//     borderColor: "#E0E0E0", // Soft border for better contrast
//   },
//   image: {
//     width: 100,
//     height: 100,
//     borderRadius: 50, // Circular image
//     marginRight: 15,
//     borderWidth: 2,
//     borderColor: "#007BFF", // Blue outline for the image
//   },
//   details: {
//     flex: 1,
//     justifyContent: "center",
//   },
//   name: {
//     fontSize: 18,
//     fontWeight: "700",
//     color: "#333",
//     marginBottom: 4,
//   },
//   specialization: {
//     fontSize: 16,
//     color: "#007BFF",
//     fontWeight: "500",
//     marginBottom: 6,
//   },
//   text: {
//     fontSize: 14,
//     color: "#555",
//     marginBottom: 2,
//   },
//   timeAvailable: {
//     fontSize: 14,
//     fontWeight: "bold",
//     color: "#28A745",
//     marginTop: 4,
//   },
//   buttonContainer: {
//     flexDirection: "row",
//     marginTop: 12,
//     gap: 12,
//   },
//   bookButton: {
//     backgroundColor: "#007BFF",
//     paddingVertical: 10,
//     paddingHorizontal: 14,
//     borderRadius: 8,
//     flex: 1,
//     alignItems: "center",
//     shadowColor: "#000",
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, height: 1 },
//     shadowRadius: 2,
//     elevation: 2,
//   },
//   consultButton: {
//     backgroundColor: "#28A745",
//     paddingVertical: 10,
//     paddingHorizontal: 14,
//     borderRadius: 8,
//     flex: 1,
//     alignItems: "center",
//     shadowColor: "#000",
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, height: 1 },
//     shadowRadius: 2,
//     elevation: 2,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 10,
//     fontWeight: "600",
//   },
// });

// export default DentistsListScreen;





// import React, { useEffect, useState } from "react";
// import {
//   View,
//   Text,
//   FlatList,
//   TouchableOpacity,
//   Image,
//   StyleSheet,
//   ActivityIndicator,
// } from "react-native";
// import { collection, getDocs } from "firebase/firestore";
// import { getAuth } from "firebase/auth"; // Import Firebase Auth
// import { db } from "../firebaseConfig"; // Ensure Firebase is configured properly
// import { useNavigation } from "@react-navigation/native";

// const DentistsListScreen = () => {
//   const [dentists, setDentists] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigation = useNavigation();
//   const auth = getAuth(); // Firebase Auth instance
//   const user = auth.currentUser; // Get current logged-in user

//   useEffect(() => {
//     const fetchDentists = async () => {
//       try {
//         if (!user) {
//           console.error("No user is signed in.");
//           setLoading(false);
//           return;
//         }

//         console.log("User Email:", user.email); // Debugging - Check user email

//         const dentistsRef = collection(db, "dentists");
//         const querySnapshot = await getDocs(dentistsRef);

//         const dentistsList = querySnapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));

//         setDentists(dentistsList);
//       } catch (error) {
//         console.error("Error fetching dentists:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchDentists();
//   }, [user]); // Runs when user changes

//   if (loading) {
//     return (
//       <View style={styles.loader}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       {dentists.length === 0 ? (
//         <Text style={styles.noDentists}>No dentists found.</Text>
//       ) : (
//         <FlatList
//           data={dentists}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <View style={styles.card}>
//               <Image source={{ uri: item.imageUrl }} style={styles.image} />
//               <View style={styles.details}>
//                 <Text style={styles.name}>{item.name}</Text>
//                 <Text style={styles.specialization}>{item.specialization}</Text>
//                 <Text style={styles.text}>📧 {item.email}</Text>
//                 <Text style={styles.text}>📍 {item.location}</Text>
//                 <Text style={styles.text}>📞 {item.phone}</Text>
//                 <Text style={styles.text}>
//                   🩺 {item.experience} years experience
//                 </Text>
//                 <Text style={styles.text}>🕒 Available: {item.time}</Text>

//                 <View style={styles.buttonContainer}>
//                   {/* Book Appointment Button */}
//                   <TouchableOpacity
//                     style={styles.bookButton}
//                     onPress={() =>
//                       navigation.navigate("BookAppointmentScreen", {
//                         doctorId: item.id,
//                       })
//                     }
//                   >
//                     <Text style={styles.buttonText}>Book Appointment</Text>
//                   </TouchableOpacity>

//                   {/* Consult Online Button */}
//                   <TouchableOpacity
//                     style={styles.consultButton}
//                     onPress={() =>
//                       navigation.navigate("ChatScreen", {
//                         doctorId: item.id,
//                         doctorEmail: item.email,
//                         userEmail: user?.email, // Pass user email to ChatScreen
//                       })
//                     }
//                   >
//                     <Text style={styles.buttonText}>Consult Online</Text>
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             </View>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#F8F9FA",
//     padding: 10,
//   },
//   loader: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   card: {
//     flexDirection: "row",
//     backgroundColor: "#fff",
//     borderRadius: 12,
//     padding: 15,
//     marginVertical: 10,
//     marginHorizontal: 20,
//     shadowColor: "#000",
//     shadowOpacity: 0.1,
//     shadowOffset: { width: 0, height: 2 },
//     shadowRadius: 4,
//     elevation: 4,
//     alignItems: "center",
//     borderWidth: 1,
//     borderColor: "#E0E0E0",
//   },
//   image: {
//     width: 100,
//     height: 100,
//     borderRadius: 50,
//     marginRight: 15,
//     borderWidth: 2,
//     borderColor: "#007BFF",
//   },
//   details: {
//     flex: 1,
//     justifyContent: "center",
//   },
//   name: {
//     fontSize: 18,
//     fontWeight: "700",
//     color: "#333",
//     marginBottom: 4,
//   },
//   specialization: {
//     fontSize: 16,
//     color: "#007BFF",
//     fontWeight: "500",
//     marginBottom: 6,
//   },
//   text: {
//     fontSize: 14,
//     color: "#555",
//     marginBottom: 2,
//   },
//   buttonContainer: {
//     flexDirection: "row",
//     marginTop: 12,
//     gap: 12,
//   },
//   bookButton: {
//     backgroundColor: "#007BFF",
//     paddingVertical: 10,
//     paddingHorizontal: 14,
//     borderRadius: 8,
//     flex: 1,
//     alignItems: "center",
//   },
//   consultButton: {
//     backgroundColor: "#28A745",
//     paddingVertical: 10,
//     paddingHorizontal: 14,
//     borderRadius: 8,
//     flex: 1,
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 12,
//     fontWeight: "600",
//   },
// });

// export default DentistsListScreen;




// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from "react-native";
// import { collection, doc, getDoc, setDoc, getDocs, serverTimestamp } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";
// import { useNavigation } from "@react-navigation/native";

// const DentistList = () => {
//   const [dentists, setDentists] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigation = useNavigation();

//   useEffect(() => {
//     const fetchDentists = async () => {
//       try {
//         const querySnapshot = await getDocs(collection(db, "dentists"));
//         const dentistList = querySnapshot.docs.map((doc) => ({
//           id: doc.id,
//           ...doc.data(),
//         }));
//         setDentists(dentistList);
//       } catch (error) {
//         console.error("Error fetching dentists:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchDentists();
//   }, []);

//   const startChat = async (doctorEmail) => {
//     try {
//       const currentUser = auth.currentUser;
//       if (!currentUser) {
//         console.error("User not logged in");
//         return;
//       }

//       const userEmail = currentUser.email;
//       const chatId = `${doctorEmail}_${userEmail}`; // Unique chat ID using emails

//       const chatRef = doc(db, "chats", chatId);

//       // Check if chat exists
//       const chatSnap = await getDoc(chatRef);

//       if (!chatSnap.exists()) {
//         // Create a new chat if it doesn't exist
//         await setDoc(chatRef, {
//           user1: userEmail,
//           user2: doctorEmail,
//           lastMessage: "",
//           timestamp: serverTimestamp(),
//         });
//       }

//       // Navigate to ChatScreen with chatId
//       navigation.navigate("ChatScreen", { chatId });

//     } catch (error) {
//       console.error("Error starting chat:", error);
//     }
//   };

//   if (loading) {
//     return <ActivityIndicator size="large" color="#0000ff" />;
//   }

//   return (
//     <View style={{ flex: 1, padding: 20 }}>
//       <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 10 }}>
//         Dentists List
//       </Text>
//       <FlatList
//         data={dentists}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <TouchableOpacity
//             style={{
//               padding: 15,
//               backgroundColor: "#f1f1f1",
//               marginVertical: 5,
//               borderRadius: 10,
//             }}
//             onPress={() => startChat(item.email)}
//           >
//             <Text style={{ fontSize: 16 }}>{item.name}</Text>
//             <Text style={{ color: "gray" }}>{item.email}</Text>
//           </TouchableOpacity>
//         )}
//       />
//     </View>
//   );
// };

// export default DentistList;


import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  StyleSheet,
} from "react-native";
import {
  collection,
  doc,
  getDoc,
  setDoc,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "../firebaseConfig";
import { useNavigation } from "@react-navigation/native";

const DentistList = () => {
  const [dentists, setDentists] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation();

  useEffect(() => {
    const fetchDentists = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "dentists"));
        const dentistList = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setDentists(dentistList);
      } catch (error) {
        console.error("Error fetching dentists:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDentists();
  }, []);

  const handleChatNavigation = async (doctor) => {
    try {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        console.error("User not logged in");
        return;
      }

      const userEmail = currentUser.email;
      const doctorEmail = doctor.email;
      const chatId = `${doctorEmail}_${userEmail}`;

      const chatRef = doc(db, "chats", chatId);
      const chatSnap = await getDoc(chatRef);

      if (!chatSnap.exists()) {
        await setDoc(chatRef, {
          user1: userEmail,
          user2: doctorEmail,
          lastMessage: "",
          timestamp: serverTimestamp(),
        });
      }

      navigation.navigate("ChatScreen", { chatId });

    } catch (error) {
      console.error("Error starting chat:", error);
    }
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#007BFF" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {dentists.length === 0 ? (
        <Text style={styles.noDentists}>No dentists found.</Text>
      ) : (
        <FlatList
          data={dentists}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Image source={{ uri: item.profileImage }}  style={styles.image} />
              <View style={styles.details}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.specialization}>{item.specialization}</Text>
                <Text style={styles.text}>📧 {item.email}</Text>
                <Text style={styles.text}>📍 {item.location}</Text>
                <Text style={styles.text}>📞 {item.phone}</Text>
                <Text style={styles.text}>
                  🩺 {item.experience} years experience
                </Text>
                <Text style={styles.text}>🕒 Available: {item.time}</Text>

                <View style={styles.buttonContainer}>
                  {/* Book Appointment Button */}
                  <TouchableOpacity
                    style={styles.bookButton}
                    onPress={() =>
                      navigation.navigate("AppointmentScreen", {
                        doctorId: item.id,
                      })
                    }
                  >
                    <Text style={styles.buttonText}>Book Appointment</Text>
                  </TouchableOpacity>

                  {/* Consult Online Button */}
                  <TouchableOpacity
                    style={styles.consultButton}
                    onPress={() => handleChatNavigation(item)}
                  >
                    <Text style={styles.buttonText}>Consult Online</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
};

// --- Styles ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F9FA",
    padding: 10,
  },
  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 15,
    marginVertical: 10,
    marginHorizontal: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 4,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#E0E0E0",
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginRight: 15,
    borderWidth: 2,
    borderColor: "#007BFF",
  },
  details: {
    flex: 1,
    justifyContent: "center",
  },
  name: {
    fontSize: 18,
    fontWeight: "700",
    color: "#333",
    marginBottom: 4,
  },
  specialization: {
    fontSize: 16,
    color: "#007BFF",
    fontWeight: "500",
    marginBottom: 6,
  },
  text: {
    fontSize: 14,
    color: "#555",
    marginBottom: 2,
  },
  buttonContainer: {
    flexDirection: "row",
    marginTop: 12,
    gap: 12,
  },
  bookButton: {
    backgroundColor: "#007BFF",
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    flex: 1,
    alignItems: "center",
  },
  consultButton: {
    backgroundColor: "#28A745",
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    flex: 1,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
  },
});

export default DentistList;
