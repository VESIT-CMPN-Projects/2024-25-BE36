// // import React, { useState } from "react";
// // import {
// //   View,
// //   Text,
// //   TextInput,
// //   TouchableOpacity,
// //   FlatList,
// //   StyleSheet,
// // } from "react-native";
// // import { Ionicons } from "@expo/vector-icons";

// // const ChatbotScreen = ({ navigation }) => {
// //   const [messages, setMessages] = useState([
// //     {
// //       id: "1",
// //       text: "Hello! How can I assist you with your dental concerns?",
// //       sender: "bot",
// //     },
// //   ]);
// //   const [inputText, setInputText] = useState("");

// //   const sendMessage = () => {
// //     if (inputText.trim() === "") return;

// //     const userMessage = {
// //       id: Date.now().toString(),
// //       text: inputText,
// //       sender: "user",
// //     };
// //     setMessages([...messages, userMessage]);
// //     setInputText("");

// //     // Display "I will start working soon" as a bot message
// //     setTimeout(() => {
// //       const botResponse = {
// //         id: (Date.now() + 1).toString(),
// //         text: "I will start working soon...",
// //         sender: "bot",
// //       };
// //       setMessages((prevMessages) => [...prevMessages, botResponse]);
// //     }, 500);
// //   };

// //   return (
// //     <View style={styles.container}>
// //       {/* Header */}
// //       <View style={styles.header}>
// //         <TouchableOpacity onPress={() => navigation.goBack()}>
// //           <Ionicons name="arrow-back" size={28} color="white" />
// //         </TouchableOpacity>
// //         <Text style={styles.headerTitle}>Dental Chatbot</Text>
// //       </View>

// //       {/* Chat Messages */}
// //       <FlatList
// //         data={messages}
// //         keyExtractor={(item) => item.id}
// //         renderItem={({ item }) => (
// //           <View
// //             style={[
// //               styles.messageBubble,
// //               item.sender === "user" ? styles.userBubble : styles.botBubble,
// //             ]}
// //           >
// //             <Text style={styles.messageText}>{item.text}</Text>
// //           </View>
// //         )}
// //         contentContainerStyle={styles.messagesContainer}
// //       />

// //       {/* Input Box */}
// //       <View style={styles.inputContainer}>
// //         <TextInput
// //           style={styles.input}
// //           placeholder="Type your message..."
// //           value={inputText}
// //           onChangeText={setInputText}
// //         />
// //         <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
// //           <Ionicons name="send" size={24} color="white" />
// //         </TouchableOpacity>
// //       </View>
// //     </View>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: "#EAF4FC",
// //   },
// //   header: {
// //     backgroundColor: "#0288D1",
// //     paddingVertical: 15,
// //     flexDirection: "row",
// //     alignItems: "center",
// //     paddingHorizontal: 20,
// //   },
// //   headerTitle: {
// //     color: "white",
// //     fontSize: 20,
// //     fontWeight: "bold",
// //     marginLeft: 10,
// //   },
// //   messagesContainer: {
// //     flexGrow: 1,
// //     padding: 15,
// //   },
// //   messageBubble: {
// //     padding: 12,
// //     borderRadius: 12,
// //     maxWidth: "80%",
// //     marginVertical: 5,
// //   },
// //   userBubble: {
// //     backgroundColor: "#0288D1",
// //     alignSelf: "flex-end",
// //   },
// //   botBubble: {
// //     backgroundColor: "#D1ECF1",
// //     alignSelf: "flex-start",
// //   },
// //   messageText: {
// //     color: "#000",
// //     fontSize: 16,
// //   },
// //   inputContainer: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     padding: 10,
// //     backgroundColor: "#FFF",
// //     borderTopWidth: 1,
// //     borderColor: "#CCC",
// //   },
// //   input: {
// //     flex: 1,
// //     padding: 10,
// //     fontSize: 16,
// //     borderWidth: 1,
// //     borderColor: "#CCC",
// //     borderRadius: 8,
// //     marginRight: 10,
// //   },
// //   sendButton: {
// //     backgroundColor: "#0288D1",
// //     padding: 10,
// //     borderRadius: 50,
// //   },
// // });

// // export default ChatbotScreen;
// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   StyleSheet,
//   SafeAreaView,
// } from "react-native";
// import { Ionicons } from "@expo/vector-icons";

// const ChatbotScreen = ({ navigation }) => {
//   const [messages, setMessages] = useState([
//     {
//       id: "1",
//       text: "Hello! How can I assist you with your dental concerns?",
//       sender: "bot",
//     },
//   ]);
//   const [inputText, setInputText] = useState("");

//   const sendMessage = () => {
//     if (inputText.trim() === "") return;

//     const userMessage = {
//       id: Date.now().toString(),
//       text: inputText,
//       sender: "user",
//     };
//     setMessages([...messages, userMessage]);
//     setInputText("");

//     // Display "I will start working soon" as a bot message
//     setTimeout(() => {
//       const botResponse = {
//         id: (Date.now() + 1).toString(),
//         text: "I will start working soon...",
//         sender: "bot",
//       };
//       setMessages((prevMessages) => [...prevMessages, botResponse]);
//     }, 500);
//   };

//   return (
//     <SafeAreaView style={styles.safeContainer}>
//       <View style={styles.header}>
//         <TouchableOpacity
//           onPress={() => navigation.goBack()}
//           style={styles.backButton}
//         >
//           <Ionicons name="arrow-back" size={28} color="white" />
//         </TouchableOpacity>
//         <Text style={styles.headerTitle}>Dental Chatbot</Text>
//       </View>

//       {/* Chat Messages */}
//       <FlatList
//         data={messages}
//         keyExtractor={(item) => item.id}
//         renderItem={({ item }) => (
//           <View
//             style={[
//               styles.messageBubble,
//               item.sender === "user" ? styles.userBubble : styles.botBubble,
//             ]}
//           >
//             <Text style={styles.messageText}>{item.text}</Text>
//           </View>
//         )}
//         contentContainerStyle={styles.messagesContainer}
//       />

//       {/* Input Box */}
//       <View style={styles.inputContainer}>
//         <TextInput
//           style={styles.input}
//           placeholder="Type your message..."
//           value={inputText}
//           onChangeText={setInputText}
//         />
//         <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
//           <Ionicons name="send" size={24} color="white" />
//         </TouchableOpacity>
//       </View>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   safeContainer: {
//     flex: 1,
//     backgroundColor: "#EAF4FC",
//   },
//   header: {
//     backgroundColor: "#0288D1",
//     paddingVertical: 15,
//     flexDirection: "row",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     justifyContent: "center",
//     height: 60, // Ensures good spacing below notification bar
//   },
//   backButton: {
//     position: "absolute",
//     left: 15,
//   },
//   headerTitle: {
//     color: "white",
//     fontSize: 20,
//     fontWeight: "bold",
//   },
//   messagesContainer: {
//     flexGrow: 1,
//     padding: 15,
//   },
//   messageBubble: {
//     padding: 12,
//     borderRadius: 12,
//     maxWidth: "80%",
//     marginVertical: 5,
//   },
//   userBubble: {
//     backgroundColor: "#0288D1",
//     alignSelf: "flex-end",
//   },
//   botBubble: {
//     backgroundColor: "#D1ECF1",
//     alignSelf: "flex-start",
//   },
//   messageText: {
//     color: "#000",
//     fontSize: 16,
//   },
//   inputContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     padding: 10,
//     backgroundColor: "#FFF",
//     borderTopWidth: 1,
//     borderColor: "#CCC",
//   },
//   input: {
//     flex: 1,
//     padding: 10,
//     fontSize: 16,
//     borderWidth: 1,
//     borderColor: "#CCC",
//     borderRadius: 8,
//     marginRight: 10,
//   },
//   sendButton: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 50,
//   },
// });

// export default ChatbotScreen;
// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   StyleSheet,
//   SafeAreaView,
//   KeyboardAvoidingView,
//   Platform,
//   ScrollView,
//   TouchableWithoutFeedback,
//   Keyboard
// } from "react-native";
// import { Ionicons } from "@expo/vector-icons";

// const ChatbotScreen = ({ navigation }) => {
//   const [messages, setMessages] = useState([
//     { id: "1", text: "Hello! How can I assist you with your dental concerns?", sender: "bot" }
//   ]);
//   const [inputText, setInputText] = useState("");

//   const sendMessage = () => {
//     if (inputText.trim() === "") return;

//     const userMessage = { id: Date.now().toString(), text: inputText, sender: "user" };
//     setMessages([...messages, userMessage]);
//     setInputText("");

//     // Display "I will start working soon" as a bot message
//     setTimeout(() => {
//       const botResponse = {
//         id: (Date.now() + 1).toString(),
//         text: "I will start working soon...",
//         sender: "bot",
//       };
//       setMessages((prevMessages) => [...prevMessages, botResponse]);
//     }, 500);
//   };

//   return (
//     <SafeAreaView style={styles.safeContainer}>
//       <KeyboardAvoidingView
//         behavior={Platform.OS === "ios" ? "padding" : "height"}
//         style={styles.keyboardAvoidingView}
//       >
//         <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
//           <View style={styles.container}>

//             {/* Header */}
//             <View style={styles.header}>
//               <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
//                 <Ionicons name="arrow-back" size={28} color="white" />
//               </TouchableOpacity>
//               <Text style={styles.headerTitle}>Dental Chatbot</Text>
//             </View>

//             {/* Chat Messages */}
//             <FlatList
//               data={messages}
//               keyExtractor={(item) => item.id}
//               renderItem={({ item }) => (
//                 <View style={[styles.messageBubble, item.sender === "user" ? styles.userBubble : styles.botBubble]}>
//                   <Text style={styles.messageText}>{item.text}</Text>
//                 </View>
//               )}
//               contentContainerStyle={styles.messagesContainer}
//               keyboardShouldPersistTaps="handled"
//             />

//             {/* Input Box */}
//             <View style={styles.inputContainer}>
//               <TextInput
//                 style={styles.input}
//                 placeholder="Type your message..."
//                 value={inputText}
//                 onChangeText={setInputText}
//               />
//               <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
//                 <Ionicons name="send" size={24} color="white" />
//               </TouchableOpacity>
//             </View>
//           </View>
//         </TouchableWithoutFeedback>
//       </KeyboardAvoidingView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   safeContainer: {
//     flex: 1,
//     backgroundColor: "#EAF4FC",
//   },
//   keyboardAvoidingView: {
//     flex: 1,
//   },
//   container: {
//     flex: 1,
//   },
//   header: {
//     backgroundColor: "#0288D1",
//     paddingVertical: 15,
//     flexDirection: "row",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     justifyContent: "center",
//     height: 60,
//   },
//   backButton: {
//     position: "absolute",
//     left: 15,
//   },
//   headerTitle: {
//     color: "white",
//     fontSize: 20,
//     fontWeight: "bold",
//   },
//   messagesContainer: {
//     flexGrow: 1,
//     padding: 15,
//   },
//   messageBubble: {
//     padding: 12,
//     borderRadius: 12,
//     maxWidth: "80%",
//     marginVertical: 5,
//   },
//   userBubble: {
//     backgroundColor: "#0288D1",
//     alignSelf: "flex-end",
//   },
//   botBubble: {
//     backgroundColor: "#D1ECF1",
//     alignSelf: "flex-start",
//   },
//   messageText: {
//     color: "#000",
//     fontSize: 16,
//   },
//   inputContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     padding: 10,
//     backgroundColor: "#FFF",
//     borderTopWidth: 1,
//     borderColor: "#CCC",
//   },
//   input: {
//     flex: 1,
//     padding: 10,
//     fontSize: 16,
//     borderWidth: 1,
//     borderColor: "#CCC",
//     borderRadius: 8,
//     marginRight: 10,
//   },
//   sendButton: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 50,
//   },
// });

// export default ChatbotScreen;

// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   StyleSheet,
//   SafeAreaView,
//   KeyboardAvoidingView,
//   Platform,
//   TouchableWithoutFeedback,
//   Keyboard,
//   ActivityIndicator,
// } from "react-native";
// import { Ionicons } from "@expo/vector-icons";

// const ChatbotScreen = ({ navigation }) => {
//   const [messages, setMessages] = useState([
//     { id: "1", text: "Hello! How can I assist you with your dental concerns?", sender: "bot" }
//   ]);
//   const [inputText, setInputText] = useState("");
//   const [loading, setLoading] = useState(false);

//   // Function to send user message to backend
//   const sendMessage = async () => {
//     if (inputText.trim() === "") return;

//     const userMessage = { id: Date.now().toString(), text: inputText, sender: "user" };
//     setMessages([...messages, userMessage]);
//     setInputText("");
//     setLoading(true);

//     try {
//       const response = await fetch("http://192.168.29.249:5001/chat", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ message: inputText }),
//       });

//       const data = await response.json();

//       // Ensure the API response contains a message
//       if (data.response) {
//         const botResponse = {
//           id: (Date.now() + 1).toString(),
//           text: data.response,
//           sender: "bot",
//         };
//         setMessages((prevMessages) => [...prevMessages, botResponse]);
//       } else {
//         throw new Error("Invalid response from server");
//       }
//     } catch (error) {
//       console.error("Error fetching chatbot response:", error);
//       setMessages((prevMessages) => [
//         ...prevMessages,
//         { id: Date.now().toString(), text: "Error getting response", sender: "bot" }
//       ]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <SafeAreaView style={styles.safeContainer}>
//       <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.keyboardAvoidingView}>
//         <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
//           <View style={styles.container}>

//             {/* Header */}
//             <View style={styles.header}>
//               <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
//                 <Ionicons name="arrow-back" size={28} color="white" />
//               </TouchableOpacity>
//               <Text style={styles.headerTitle}>Dental Chatbot</Text>
//             </View>

//             {/* Chat Messages */}
//             <FlatList
//               data={messages}
//               keyExtractor={(item) => item.id}
//               renderItem={({ item }) => (
//                 <View style={[styles.messageBubble, item.sender === "user" ? styles.userBubble : styles.botBubble]}>
//                   <Text style={styles.messageText}>{item.text}</Text>
//                 </View>
//               )}
//               contentContainerStyle={styles.messagesContainer}
//               keyboardShouldPersistTaps="handled"
//             />

//             {/* Loading Indicator */}
//             {loading && <ActivityIndicator size="large" color="#0288D1" style={styles.loader} />}

//             {/* Input Box */}
//             <View style={styles.inputContainer}>
//               <TextInput
//                 style={styles.input}
//                 placeholder="Type your message..."
//                 value={inputText}
//                 onChangeText={setInputText}
//               />
//               <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
//                 <Ionicons name="send" size={24} color="white" />
//               </TouchableOpacity>
//             </View>
//           </View>
//         </TouchableWithoutFeedback>
//       </KeyboardAvoidingView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   safeContainer: { flex: 1, backgroundColor: "#EAF4FC" },
//   keyboardAvoidingView: { flex: 1 },
//   container: { flex: 1 },
//   header: {
//     backgroundColor: "#0288D1",
//     paddingVertical: 15,
//     flexDirection: "row",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     justifyContent: "center",
//     height: 60,
//   },
//   backButton: { position: "absolute", left: 15 },
//   headerTitle: { color: "white", fontSize: 20, fontWeight: "bold" },
//   messagesContainer: { flexGrow: 1, padding: 15 },
//   messageBubble: { padding: 12, borderRadius: 12, maxWidth: "80%", marginVertical: 5 },
//   userBubble: { backgroundColor: "#0288D1", alignSelf: "flex-end" },
//   botBubble: { backgroundColor: "#D1ECF1", alignSelf: "flex-start" },
//   messageText: { color: "#000", fontSize: 16 },
//   inputContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     padding: 10,
//     backgroundColor: "#FFF",
//     borderTopWidth: 1,
//     borderColor: "#CCC",
//   },
//   input: {
//     flex: 1,
//     padding: 10,
//     fontSize: 16,
//     borderWidth: 1,
//     borderColor: "#CCC",
//     borderRadius: 8,
//     marginRight: 10,
//   },
//   sendButton: { backgroundColor: "#0288D1", padding: 10, borderRadius: 50 },
//   loader: { marginVertical: 10, alignSelf: "center" },
// });

// export default ChatbotScreen;
// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   FlatList,
//   StyleSheet,
//   SafeAreaView,
//   KeyboardAvoidingView,
//   Platform,
//   TouchableWithoutFeedback,
//   Keyboard,
//   ActivityIndicator,
// } from "react-native";
// import { Ionicons } from "@expo/vector-icons";

// const ChatbotScreen = ({ navigation }) => {
//   const [messages, setMessages] = useState([
//     { id: "1", text: "Hello! How can I assist you with your dental concerns?", sender: "bot" }
//   ]);
//   const [inputText, setInputText] = useState("");
//   const [loading, setLoading] = useState(false);

//   // Function to send user message to backend
//   const sendMessage = async () => {
//     if (inputText.trim() === "") return;

//     const userMessage = { id: Date.now().toString(), text: inputText, sender: "user" };
//     setMessages([...messages, userMessage]);
//     setInputText("");
//     setLoading(true);

//     try {
//       const response = await fetch("http://192.168.29.249:5001/chat", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ message: inputText }),
//       });

//       const data = await response.json();

//       if (data.response) {
//         const botResponse = {
//           id: (Date.now() + 1).toString(),
//           text: data.response,
//           sender: "bot",
//         };
//         setMessages((prevMessages) => [...prevMessages, botResponse]);
//       } else {
//         throw new Error("Invalid response from server");
//       }
//     } catch (error) {
//       console.error("Error fetching chatbot response:", error);
//       setMessages((prevMessages) => [
//         ...prevMessages,
//         { id: Date.now().toString(), text: "Error getting response", sender: "bot" }
//       ]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <SafeAreaView style={styles.safeContainer}>
//       <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.keyboardAvoidingView}>
//         <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
//           <View style={styles.container}>

//             {/* Header */}
//             <View style={styles.header}>
//               <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
//                 <Ionicons name="arrow-back" size={28} color="white" />
//               </TouchableOpacity>
//               <Text style={styles.headerTitle}>Dental Chatbot</Text>
//             </View>

//             {/* Chat Messages */}
//             <FlatList
//               data={[...messages].reverse()} // Reverse to show latest at bottom
//               keyExtractor={(item) => item.id}
//               renderItem={({ item }) => (
//                 <View style={[styles.messageBubble, item.sender === "user" ? styles.userBubble : styles.botBubble]}>
//                   <Text style={styles.messageText}>{item.text}</Text>
//                 </View>
//               )}
//               contentContainerStyle={styles.messagesContainer}
//               keyboardShouldPersistTaps="handled"
//               inverted={true} // Ensures new messages appear at the bottom
//               ListFooterComponent={<View style={{ height: 10 }} />} // Adds space at bottom
//             />

//             {/* Loading Indicator */}
//             {loading && <ActivityIndicator size="large" color="#0288D1" style={styles.loader} />}

//             {/* Input Box */}
//             <View style={styles.inputContainer}>
//               <TextInput
//                 style={styles.input}
//                 placeholder="Type your message..."
//                 value={inputText}
//                 onChangeText={setInputText}
//               />
//               <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
//                 <Ionicons name="send" size={24} color="white" />
//               </TouchableOpacity>
//             </View>
//           </View>
//         </TouchableWithoutFeedback>
//       </KeyboardAvoidingView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   safeContainer: { flex: 1, backgroundColor: "#EAF4FC" },
//   keyboardAvoidingView: { flex: 1 },
//   container: { flex: 1 },
//   header: {
//     backgroundColor: "#0288D1",
//     paddingVertical: 15,
//     flexDirection: "row",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     justifyContent: "center",
//     height: 60,
//   },
//   backButton: { position: "absolute", left: 15 },
//   headerTitle: { color: "white", fontSize: 20, fontWeight: "bold" },
//   messagesContainer: { flexGrow: 1, justifyContent: "flex-end", padding: 15 },
//   messageBubble: { padding: 12, borderRadius: 12, maxWidth: "80%", marginVertical: 5 },
//   userBubble: { backgroundColor: "#0288D1", alignSelf: "flex-end" },
//   botBubble: { backgroundColor: "#D1ECF1", alignSelf: "flex-start" },
//   messageText: { color: "#000", fontSize: 16 },
//   inputContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     padding: 10,
//     backgroundColor: "#FFF",
//     borderTopWidth: 1,
//     borderColor: "#CCC",
//   },
//   input: {
//     flex: 1,
//     padding: 10,
//     fontSize: 16,
//     borderWidth: 1,
//     borderColor: "#CCC",
//     borderRadius: 8,
//     marginRight: 10,
//   },
//   sendButton: { backgroundColor: "#0288D1", padding: 10, borderRadius: 50 },
//   loader: { marginVertical: 10, alignSelf: "center" },
// });

// export default ChatbotScreen;
import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const ChatbotScreen = ({ navigation }) => {
  const [messages, setMessages] = useState([
    {
      id: "1",
      text: "Hello! How can I assist you with your dental concerns?",
      sender: "bot",
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const flatListRef = useRef(null); // Reference for FlatList to scroll

  // Function to send user message to backend
  const sendMessage = async () => {
    if (inputText.trim() === "") return;

    const userMessage = {
      id: Date.now().toString(),
      text: inputText,
      sender: "user",
    };
    setMessages([...messages, userMessage]);
    setInputText("");
    setLoading(true);

    try {
      const response = await fetch("http://192.168.29.249:5001/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: inputText }),
      });

      const data = await response.json();

      // Ensure the API response contains a message
      if (data.response) {
        const botResponse = {
          id: (Date.now() + 1).toString(),
          text: data.response,
          sender: "bot",
        };
        setMessages((prevMessages) => [...prevMessages, botResponse]);
      } else {
        throw new Error("Invalid response from server");
      }
    } catch (error) {
      console.error("Error fetching chatbot response:", error);
      setMessages((prevMessages) => [
        ...prevMessages,
        {
          id: Date.now().toString(),
          text: "Error getting response",
          sender: "bot",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeContainer}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardAvoidingView}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
              <TouchableOpacity
                onPress={() => navigation.goBack()}
                style={styles.backButton}
              >
                <Ionicons name="arrow-back" size={28} color="white" />
              </TouchableOpacity>
              <Text style={styles.headerTitle}>Dental Chatbot</Text>
            </View>

            {/* Chat Messages */}
            <FlatList
              ref={flatListRef}
              data={[...messages].reverse()} // Reversing messages so new ones appear at the bottom
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View
                  style={[
                    styles.messageBubble,
                    item.sender === "user"
                      ? styles.userBubble
                      : styles.botBubble,
                  ]}
                >
                  <Text style={styles.messageText}>{item.text}</Text>
                </View>
              )}
              inverted // Keeps the latest messages at the bottom
              contentContainerStyle={styles.messagesContainer}
              keyboardShouldPersistTaps="handled"
              onContentSizeChange={() =>
                flatListRef.current?.scrollToEnd({ animated: true })
              } // Auto-scroll
            />

            {/* Loading Indicator */}
            {loading && (
              <ActivityIndicator
                size="large"
                color="#0288D1"
                style={styles.loader}
              />
            )}

            {/* Input Box */}
            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="Type your message..."
                value={inputText}
                onChangeText={setInputText}
              />
              <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
                <Ionicons name="send" size={24} color="white" />
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeContainer: { flex: 1, backgroundColor: "#EAF4FC" },
  keyboardAvoidingView: { flex: 1 },
  container: { flex: 1 },
  header: {
    backgroundColor: "#0288D1",
    paddingVertical: 15,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    justifyContent: "center",
    height: 60,
  },
  backButton: { position: "absolute", left: 15 },
  headerTitle: { color: "white", fontSize: 20, fontWeight: "bold" },
  messagesContainer: { flexGrow: 1, padding: 15 },
  messageBubble: {
    padding: 12,
    borderRadius: 12,
    maxWidth: "80%",
    marginVertical: 5,
  },
  userBubble: { backgroundColor: "#0288D1", alignSelf: "flex-end" },
  botBubble: { backgroundColor: "#D1ECF1", alignSelf: "flex-start" },
  messageText: { color: "#000", fontSize: 16 },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    backgroundColor: "#FFF",
    borderTopWidth: 1,
    borderColor: "#CCC",
  },
  input: {
    flex: 1,
    padding: 10,
    fontSize: 16,
    borderWidth: 1,
    borderColor: "#CCC",
    borderRadius: 8,
    marginRight: 10,
  },
  sendButton: { backgroundColor: "#0288D1", padding: 10, borderRadius: 50 },
  loader: { marginVertical: 10, alignSelf: "center" },
});

export default ChatbotScreen;
