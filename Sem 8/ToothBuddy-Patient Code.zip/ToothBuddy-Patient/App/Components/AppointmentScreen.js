// import React from "react";
// import { View, Text, StyleSheet } from "react-native";

// const AppointmentScreen = () => {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.text}>Appointment Page</Text>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#F8F9FA",
//   },
//   text: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#333",
//   },
// });

// export default AppointmentScreen;

// import React, { useState, useEffect } from "react";
// import { View, Text, Button, Alert, StyleSheet } from "react-native";
// import DateTimePicker from "@react-native-community/datetimepicker";
// import { collection, query, where, getDocs } from "firebase/firestore";
// import { auth, db } from "../firebaseConfig";

// const AppointmentScreen = ({ route, navigation }) => {
//   const { doctorId } = route.params; // Get the dentist's ID
//   const [selectedDate, setSelectedDate] = useState(new Date());
//   const [userName, setUserName] = useState("");
//   const [userEmail, setUserEmail] = useState(auth.currentUser?.email || "");
//   const [showPicker, setShowPicker] = useState(false);


// useEffect(() => {
//   const fetchUserDetails = async () => {
//     if (!userEmail) return;

//     try {
//       const usersRef = collection(db, "users"); // Reference to users collection
//       const q = query(usersRef, where("email", "==", userEmail)); // Query by email
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         const userData = querySnapshot.docs[0].data(); // Get first matching document
//         setUserName(userData.name);
//       } else {
//         console.log("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     }
//   };

//   fetchUserDetails();
// }, [userEmail]);

//   const handleConfirm = async () => {
//     try {
//       const appointmentRef = doc(
//         db,
//         "dentists",
//         doctorId,
//         "appointments",
//         userEmail
//       );

//       await setDoc(appointmentRef, {
//         userId: userEmail,
//         userName: userName,
//         appointmentDate: selectedDate.toISOString(),
//       });

//       Alert.alert("Success", "Appointment booked successfully!", [
//         { text: "OK", onPress: () => navigation.goBack() },
//       ]);
//     } catch (error) {
//       console.error("Error booking appointment:", error);
//       Alert.alert("Error", "Failed to book appointment. Try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.header}>Book an Appointment</Text>

//       <Text style={styles.label}>Select a Date:</Text>
//       <Button title="Pick a Date" onPress={() => setShowPicker(true)} />

//       {showPicker && (
//         <DateTimePicker
//           value={selectedDate}
//           mode="date"
//           display="default"
//           onChange={(event, date) => {
//             setShowPicker(false);
//             if (date) setSelectedDate(date);
//           }}
//         />
//       )}

//       <Text style={styles.selectedDate}>
//         Selected Date: {selectedDate.toDateString()}
//       </Text>

//       <Button title="Confirm Appointment" onPress={handleConfirm} />
//     </View>
//   );
// };

// // --- Styles ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     padding: 20,
//     backgroundColor: "#f8f9fa",
//   },
//   header: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//   },
//   label: {
//     fontSize: 16,
//     marginBottom: 10,
//   },
//   selectedDate: {
//     fontSize: 16,
//     marginVertical: 10,
//     fontWeight: "500",
//     color: "#007BFF",
//   },
// });

// export default AppointmentScreen;




import React, { useState, useEffect } from "react";
import { View, Text, Button, Alert, StyleSheet, ActivityIndicator } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { collection, query, where, getDocs, doc, setDoc } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";

const AppointmentScreen = ({ route, navigation }) => {
  const { doctorId } = route.params; // Get the dentist's ID
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState(auth.currentUser?.email || "");
  const [showPicker, setShowPicker] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserDetails = async () => {
      if (!userEmail) return;

      try {
        const usersRef = collection(db, "users"); // Reference to users collection
        const q = query(usersRef, where("email", "==", userEmail)); // Query by email
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          const userData = querySnapshot.docs[0].data(); // Get first matching document
          setUserName(userData.name);
        } else {
          console.log("User not found in Firestore");
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserDetails();
  }, [userEmail]);

  const handleConfirm = async () => {
    if (!userName) {
      Alert.alert("Error", "User details not found. Please try again.");
      return;
    }
    try {
      const appointmentRef = doc(db, "dentists", doctorId, "appointments", userEmail);

      await setDoc(appointmentRef, {
        userId: userEmail,
        Name: userName,
        appointmentDate: selectedDate.toISOString(),
      });

      Alert.alert("Success", "Appointment booked successfully!", [
        { text: "OK", onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      console.error("Error booking appointment:", error);
      Alert.alert("Error", "Failed to book appointment. Try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Book an Appointment</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#007BFF" />
      ) : (
        <>
          <Text style={styles.label}>Select a Date:</Text>
          <Button title="Pick a Date" onPress={() => setShowPicker(true)} />

          {showPicker && (
            <DateTimePicker
              value={selectedDate}
              mode="date"
              display="default"
              onChange={(event, date) => {
                setShowPicker(false);
                if (date) setSelectedDate(date);
              }}
            />
          )}

          <Text style={styles.selectedDate}>
            Selected Date: {selectedDate.toDateString()}
          </Text>

          <Button title="Confirm Appointment" onPress={handleConfirm} />
        </>
      )}
    </View>
  );
};

// --- Styles ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#f8f9fa",
  },
  header: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
  },
  selectedDate: {
    fontSize: 16,
    marginVertical: 10,
    fontWeight: "500",
    color: "#007BFF",
  },
});

export default AppointmentScreen;
