// // ImageUpload.js
// import React, { useState } from "react";
// import {
//   View,
//   Button,
//   Image,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
// } from "react-native";
// import * as ImagePicker from "expo-image-picker";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [detections, setDetections] = useState(null);

//   const pickImage = async () => {
//     const permissionResult =
//       await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (permissionResult.granted === false) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";

//     const formData = new FormData();
//     formData.append("file", {
//       uri,
//       name: "photo.jpg",
//       type,
//     });

//     const controller = new AbortController();
//     const timeoutId = setTimeout(() => controller.abort(), 10000); // 10-second timeout

//     try {
//       console.log("Uploading image...");
//       console.log(formData);
//       const response = await fetch("http://172.20.10.4:5000/detect", {
//         method: "POST",
//         body: formData,
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//         signal: controller.signal,
//       });
//       console.log("Done image...");
//       clearTimeout(timeoutId);

//       if (!response.ok) {
//         throw new Error("Network response was not ok");
//       }

//       const data = await response.json();
//       if (data.detections) {
//         setDetections(data.detections);
//         console.log(data.detections);
//       } else {
//         alert("No detections found");
//       }
//     } catch (error) {
//       if (error.name === "AbortError") {
//         alert("Request timed out. Please try again.");
//       } else {
//         console.error("Error uploading image:", error);
//         alert("Error uploading image. Please try again.");
//       }
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from camera roll</Text>
//       </TouchableOpacity>
//       {selectedImage && (
//         <Image source={{ uri: selectedImage }} style={styles.image} />
//       )}
//       {detections &&
//         detections.map((det, index) => (
//           <Text key={index} style={styles.detectionText}>
//             {det.label}: {det.confidence.toFixed(2)}
//           </Text>
//         ))}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
//   detectionText: {
//     marginTop: 10,
//     fontSize: 16,
//     color: "#333",
//   },
// });

// export default ImageUpload;

// // this is the front end code are there any changes to be made to the code in the frontend
// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";

//     const formData = new FormData();
//     formData.append("file", {
//       uri,
//       name: "photo.jpg",
//       type,
//     });

//     try {
//       console.log("Uploading image...");
//       const response = await fetch("http://192.168.29.249:5000/detect", {
//         method: "POST",
//         body: formData,
//         headers: { "Content-Type": "multipart/form-data" },
//       });

//       if (!response.ok) {
//         throw new Error("Network response was not ok");
//       }

//       const data = await response.json();
//       if (data.detections) {
//         console.log(data.detections);
//         // Navigate to ReportScreen with the detection results
//         navigation.navigate("Report", { detections: data.detections, imageUri: uri });
//       } else {
//         alert("No detections found");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;---code final



// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";

//     const formData = new FormData();
//     formData.append("file", {
//       uri,
//       name: "photo.jpg",
//       type,
//     });

//     try {
//       console.log("Uploading image...");
//       const response = await fetch("http://192.168.29.249:5000/detect", {
//         method: "POST",
//         body: formData,
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });

//       const data = await response.json();
//       console.log("Response from server:", data);

//       if (data.predictions && data.predictions.length > 0) {
//         navigation.navigate("Report", { detections: data.predictions, imageUri: uri });
//       } else {
//         alert("No detections found");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;
// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";

//     const formData = new FormData();
//     formData.append("file", {
//       uri,
//       name: "photo.jpg",
//       type,
//     });

//     try {
//       console.log("Uploading image...");
//       // Replace with Teminiproject API URL
//       const response = await fetch("https://detect.roboflow.com/infer/workflows/teminiproj/custom-workflow", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           api_key: "GXY6ZJTCRnW4cSjU4Oc1",
//           inputs: {
//             image: { type: "url", value: uri },
//           },
//         }),
//       });

//       const data = await response.json();
//       console.log("Response from server:", data);

//       if (data.predictions && data.predictions.length > 0) {
//         navigation.navigate("Report", { detections: data.predictions, imageUri: uri });
//       } else {
//         alert("No detections found");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;

// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const base64Image = await convertToBase64(uri);
  
//     try {
//       console.log("Uploading image...");
//       // Replace with your Teminiproject API URL
//       const response = await fetch("https://detect.roboflow.com/infer/workflows/teminiproj/custom-workflow", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           api_key: "GXY6ZJTCRnW4cSjU4Oc1",
//           inputs: {
//             image: { type: "base64", value: base64Image },
//           },
//         }),
//       });
  
//       const data = await response.json();
//       console.log("Response from server:", data);
  
//       // Check if predictions are returned and log the predictions
//       if (data.outputs && data.outputs.length > 0) {
//         const predictions = data.outputs[0].predictions;
//         console.log("Predictions:", predictions); // Log the predictions object
  
//         // Process predictions
//         const formattedPredictions = predictions.map(prediction => ({
//           class: prediction.class,
//           confidence: prediction.confidence,
//         }));
  
//         // Check if there are any predictions and navigate to the report screen
//         if (formattedPredictions.length > 0) {
//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           alert("No detections found");
//         }
//       } else {
//         alert("Error: No predictions returned from the model");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };
  

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;



// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   // Function to convert the image to base64 format
//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(',')[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   // Function to pick image from the gallery
//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   // Function to upload the image to the model API
//   const uploadImage = async (uri) => {
//     const base64Image = await convertToBase64(uri);

//     try {
//       console.log("Uploading image...");
//       // Replace with your Teminiproject API URL
//       const response = await fetch("https://detect.roboflow.com/infer/workflows/teminiproj/custom-workflow", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           api_key: "GXY6ZJTCRnW4cSjU4Oc1",
//           inputs: {
//             image: { type: "base64", value: base64Image },
//           },
//         }),
//       });

//       const data = await response.json();
//       console.log("Response from server:", data);

//       // Check if predictions are returned and log the predictions
//       if (data.outputs && data.outputs.length > 0) {
//         const predictions = data.outputs[0].predictions;
//         console.log("Predictions:", predictions); // Log the predictions object

//         // Process predictions
//         const formattedPredictions = predictions.map(prediction => ({
//           class: prediction.class,
//           confidence: prediction.confidence,
//         }));

//         // Check if there are any predictions and navigate to the report screen
//         if (formattedPredictions.length > 0) {
//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           alert("No detections found");
//         }
//       } else {
//         alert("Error: No predictions returned from the model");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;




// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   // Function to convert the image to base64 format
//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(',')[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   // Function to pick image from the gallery
//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   // Function to upload the image to the model API
//   const uploadImage = async (uri) => {
//     const base64Image = await convertToBase64(uri);

//     try {
//       console.log("Uploading image...");
//       // Replace with your Teminiproject API URL
//       const response = await fetch("https://detect.roboflow.com/infer/workflows/teminiproj/custom-workflow", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           api_key: "GXY6ZJTCRnW4cSjU4Oc1",
//           inputs: {
//             image: { type: "base64", value: base64Image },
//           },
//         }),
//       });

//       const data = await response.json();
//       console.log("Response from server:", data);

//       // Check if predictions are returned
//       if (data.outputs && data.outputs.length > 0) {
//         const predictions = data.outputs[0].predictions || [];
//         console.log("Predictions:", predictions); // Log the predictions object

//         // Process predictions if they exist
//         if (predictions.length > 0) {
//           const formattedPredictions = predictions.map(prediction => ({
//             class: prediction.class,
//             confidence: prediction.confidence,
//           }));

//           // Navigate to the report screen with formatted predictions
//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           alert("No detections found");
//         }
//       } else {
//         alert("Error: No predictions returned from the model");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;





// import React, { useState } from "react";
// import { View, Button, Image, Text, StyleSheet, TouchableOpacity } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const navigation = useNavigation();

//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(',')[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

//     if (!permissionResult.granted) {
//       alert("Permission to access camera roll is required!");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     const base64Image = await convertToBase64(uri);

//     try {
//       console.log("Uploading image...");
//       const response = await fetch("https://detect.roboflow.com/infer/workflows/teminiproj/custom-workflow", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           api_key: "GXY6ZJTCRnW4cSjU4Oc1",
//           inputs: {
//             image: { type: "base64", value: base64Image },
//           },
//         }),
//       });

//       const data = await response.json();
//       console.log("Response from server:", data);

//       if (data.outputs && data.outputs.length > 0) {
//         const predictions = data.outputs[0].predictions.predictions || []; // Fix applied

//         console.log("Predictions:", predictions);

//         if (predictions.length > 0) {
//           const formattedPredictions = predictions.map(prediction => ({
//             class: prediction.class,
//             confidence: prediction.confidence,
//           }));

//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           alert("No detections found");
//         }
//       } else {
//         alert("Error: No predictions returned from the model");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage}>
//         <Text style={styles.buttonText}>Pick an image from gallery</Text>
//       </TouchableOpacity>
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 10,
//     borderRadius: 5,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;




// import React, { useState } from "react";
// import { View, ActivityIndicator, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUpload = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const navigation = useNavigation();

//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(",")[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (!permissionResult.granted) {
//       Alert.alert("Permission Required", "Please allow access to your media library.");
//       return;
//     }
    
//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });
    
//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//       await uploadImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     setLoading(true);
//     const base64Image = await convertToBase64(uri);
  
//     try {
//       const response = await fetch("http://192.168.29.249:5000/predict", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ image: base64Image }),
//       });
  
//       const data = await response.json();
//       console.log("Response from server:", data);
//       console.log(data[0].predictions.predictions);
  
//       // Extract predictions from the response
//       if (Array.isArray(data) && data.length > 0 && data[0].predictions) {
//         const predictions = data[0].predictions.predictions;
        
//         if (predictions.length > 0) {
//           const formattedPredictions = predictions.map(pred => ({
//             class: pred.class,
//             confidence: pred.confidence,
//           }));
  
//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           Alert.alert("No Detections", "No objects were detected in the image.");
//         }
//       } else {
//         Alert.alert("Error", "Invalid response structure from the model.");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       Alert.alert("Upload Failed", "An error occurred while processing your request.");
//     } finally {
//       setLoading(false);
//     }
//   };
  

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
//         <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
//       </TouchableOpacity>
//       {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
//       {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 8,
//     width: "80%",
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUpload;



import React, { useState } from "react";
import { View, ActivityIndicator, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useNavigation } from "@react-navigation/native";

const ImageUpload = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();

  const convertToBase64 = async (uri) => {
    const response = await fetch(uri);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result.split(",")[1]); // Extract base64 part
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert("Permission Required", "Please allow access to your media library.");
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
      await uploadImage(result.assets[0].uri);
    }
  };
  const uploadImage = async (uri) => {
    setLoading(true);
    try {
      const base64Image = await convertToBase64(uri);
  
      const response = await fetch("http://192.168.29.249:5000/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: base64Image }),
      });
  
      const data = await response.json();
      console.log("Response from server:", data[0].predictions.predictions);
      
      // Correctly access predictions array
      if (data.length > 0 && data[0].predictions && data[0].predictions.predictions.length > 0) {
        const formattedPredictions = data[0].predictions.predictions.map(pred => ({
          class: pred.class,
          confidence: pred.confidence,
        }));
  
        navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
      } else {
        Alert.alert("No Detections", "No objects were detected in the image.");
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      Alert.alert("Upload Failed", "An error occurred while processing your request.");
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Upload an Image for Detection</Text>
      <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
        <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
      </TouchableOpacity>
      {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
      {selectedImage && <Image source={{ uri: selectedImage }} style={styles.image} />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#EAF4FC",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#0288D1",
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#0288D1",
    padding: 12,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 20,
    borderRadius: 10,
  },
});

export default ImageUpload;
