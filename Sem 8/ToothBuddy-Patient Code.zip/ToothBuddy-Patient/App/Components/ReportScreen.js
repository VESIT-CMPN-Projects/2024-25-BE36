// import React from "react";
// import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity } from "react-native";

// const ReportScreen = ({ route, navigation }) => {
//   const { detections, imageUri } = route.params;

//   return (
//     <ScrollView style={styles.container}>
//       <Text style={styles.title}>Detection Report</Text>
//       <Image source={{ uri: imageUri }} style={styles.image} />

//       <View style={styles.reportContainer}>
//         <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
//         {detections.length > 0 ? (
//           detections.map((det, index) => (
//             <Text key={index} style={styles.detectionText}>
//               🦷 {det.label} (Confidence: {det.confidence.toFixed(2)}%)
//             </Text>
//           ))
//         ) : (
//           <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
//         )}
//       </View>

//       <TouchableOpacity style={styles.button} onPress={() => alert("Appointment Feature Coming Soon!")}>
//         <Text style={styles.buttonText}>Book an Appointment</Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F9FAFB",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     textAlign: "center",
//     marginBottom: 10,
//     color: "#0288D1",
//   },
//   image: {
//     width: "100%",
//     height: 250,
//     borderRadius: 10,
//     marginBottom: 20,
//   },
//   reportContainer: {
//     padding: 15,
//     backgroundColor: "#E3F2FD",
//     borderRadius: 10,
//   },
//   subtitle: {
//     fontSize: 18,
//     fontWeight: "bold",
//     color: "#01579B",
//   },
//   detectionText: {
//     fontSize: 16,
//     marginTop: 5,
//     color: "#333",
//   },
//   noDetectionText: {
//     fontSize: 16,
//     color: "green",
//     fontWeight: "bold",
//     marginTop: 5,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 15,
//     borderRadius: 10,
//     alignItems: "center",
//     marginTop: 20,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 18,
//     fontWeight: "bold",
//   },
// });

// export default ReportScreen;





// import React, { useEffect, useState } from "react";
// import { View, Text, Image, StyleSheet, ScrollView, ActivityIndicator } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, query, where, getDocs } from "firebase/firestore";
// import { MaterialIcons } from "@expo/vector-icons";

// const ReportScreen = ({ route }) => {
//   const { detections, imageUri } = route.params;
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [reportDate, setReportDate] = useState("");

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         fetchUserDetails(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     // Set the report generation date & time
//     const now = new Date();
//     const formattedDate = now.toLocaleDateString();
//     const formattedTime = now.toLocaleTimeString();
//     setReportDate(`${formattedDate} | ${formattedTime}`);

//     return () => unsubscribe();
//   }, []);

//   const fetchUserDetails = async (email) => {
//     setLoading(true);
//     try {
//       const usersRef = collection(db, "users");
//       const q = query(usersRef, where("email", "==", email));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         setUserData(querySnapshot.docs[0].data());
//       } else {
//         console.warn("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <ScrollView style={styles.container}>
//       <Text style={styles.title}>Detection Report</Text>

//       {userData && (
//         <View style={styles.userInfo}>
//           <Text style={styles.userText}>
//             <MaterialIcons name="person" size={18} color="#0288D1" /> {userData.name}
//           </Text>
//           <Text style={styles.userText}>
//             <MaterialIcons name="calendar-today" size={18} color="#0288D1" /> {reportDate}
//           </Text>
//         </View>
//       )}

//       <Image source={{ uri: imageUri }} style={styles.image} />

//       <View style={styles.reportContainer}>
//         <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
//         {detections.length > 0 ? (
//           detections.map((det, index) => (
//             <Text key={index} style={styles.detectionText}>
//               🦷 {det.label} (Confidence: {det.confidence.toFixed(2)}%)
//             </Text>
//           ))
//         ) : (
//           <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
//         )}
//       </View>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F9FAFB",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     textAlign: "center",
//     marginBottom: 10,
//     color: "#0288D1",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   userInfo: {
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 10,
//     marginBottom: 10,
//     alignItems: "center",
//   },
//   userText: {
//     fontSize: 16,
//     fontWeight: "bold",
//     color: "#01579B",
//     marginBottom: 5,
//   },
//   image: {
//     width: "100%",
//     height: 250,
//     borderRadius: 10,
//     marginBottom: 20,
//   },
//   reportContainer: {
//     padding: 15,
//     backgroundColor: "#E3F2FD",
//     borderRadius: 10,
//   },
//   subtitle: {
//     fontSize: 18,
//     fontWeight: "bold",
//     color: "#01579B",
//   },
//   detectionText: {
//     fontSize: 16,
//     marginTop: 5,
//     color: "#333",
//   },
//   noDetectionText: {
//     fontSize: 16,
//     color: "green",
//     fontWeight: "bold",
//     marginTop: 5,
//   },
// });

// export default ReportScreen;




// import React, { useEffect, useState } from "react";
// import { View, Text, Image, StyleSheet, ScrollView, ActivityIndicator, Button, Alert } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, doc, addDoc, setDoc, getDocs, query, where } from "firebase/firestore";
// import { MaterialIcons } from "@expo/vector-icons";

// const ReportScreen = ({ route }) => {
//   const { detections, imageUri } = route.params;
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [reportDate, setReportDate] = useState("");

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         fetchUserDetails(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     // Set the report generation date & time
//     const now = new Date();
//     const formattedDate = now.toLocaleDateString();
//     const formattedTime = now.toLocaleTimeString();
//     setReportDate(`${formattedDate} | ${formattedTime}`);

//     return () => unsubscribe();
//   }, []);

//   const fetchUserDetails = async (email) => {
//     setLoading(true);
//     try {
//       const usersRef = collection(db, "users");
//       const q = query(usersRef, where("email", "==", email));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         setUserData(querySnapshot.docs[0].data());
//       } else {
//         console.warn("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const saveReport = async () => {
//     if (!auth.currentUser) {
//       Alert.alert("Error", "You must be logged in to save reports.");
//       return;
//     }

//     try {
//       const userId = auth.currentUser.uid;
//       const userDocRef = doc(db, "users", userId);
//       const reportsCollectionRef = collection(userDocRef, "reports");

//       const newReport = {
//         date: reportDate,
//         detections: detections,
//         imageUri: imageUri,
//       };

//       await addDoc(reportsCollectionRef, newReport);
//       Alert.alert("Success", "Report saved successfully!");
//     } catch (error) {
//       console.error("Error saving report:", error);
//       Alert.alert("Error", "Failed to save the report.");
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

  
  
//   return (
    // <ScrollView style={styles.container}>
    //   <Text style={styles.title}>Detection Report</Text>
  
    //   {userData && (
    //     <View style={styles.userInfo}>
    //       <Text style={styles.userText}>
    //         <MaterialIcons name="person" size={18} color="#0288D1" /> {userData.name}
    //       </Text>
    //       <Text style={styles.userText}>
    //         <MaterialIcons name="calendar-today" size={18} color="#0288D1" /> {reportDate}
    //       </Text>
    //     </View>
    //   )}
  
    //   <Image source={{ uri: imageUri }} style={styles.image} />
  
    //   <View style={styles.reportContainer}>
    //     <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
    //     {detections.length > 0 ? (
    //       detections.map((det, index) => {
    //         const condition = classMapping[det.class] || "Unknown Condition";
    //         return (
    //           <Text key={index} style={styles.detectionText}>
    //             🦷 {condition} (Confidence: {det.confidence.toFixed(2)*100}%)
    //           </Text>
    //         );
    //       })
    //     ) : (
    //       <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
    //     )}
    //   </View>
  
    //   {/* Save Report Button */}
    //   <Button title="Save Report" onPress={saveReport} color="#0288D1" />
    // </ScrollView>
//   );
  
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F9FAFB",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     textAlign: "center",
//     marginBottom: 10,
//     color: "#0288D1",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   userInfo: {
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 10,
//     marginBottom: 10,
//     alignItems: "center",
//   },
//   userText: {
//     fontSize: 16,
//     fontWeight: "bold",
//     color: "#01579B",
//     marginBottom: 5,
//   },
//   image: {
//     width: "100%",
//     height: 250,
//     borderRadius: 10,
//     marginBottom: 20,
//   },
//   reportContainer: {
//     padding: 15,
//     backgroundColor: "#E3F2FD",
//     borderRadius: 10,
//     marginBottom: 10,
//   },
//   subtitle: {
//     fontSize: 18,
//     fontWeight: "bold",
//     color: "#01579B",
//   },
//   detectionText: {
//     fontSize: 16,
//     marginTop: 5,
//     color: "#333",
//   },
//   noDetectionText: {
//     fontSize: 16,
//     color: "green",
//     fontWeight: "bold",
//     marginTop: 5,
//   },
// });

// export default ReportScreen;



// import React, { useEffect, useState } from "react";
// import { View, Text, Image, StyleSheet, ScrollView, ActivityIndicator, Button, Alert } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, doc, addDoc, getDocs, query, where } from "firebase/firestore";
// import { MaterialIcons } from "@expo/vector-icons";

// const CLOUDINARY_URL = "https://api.cloudinary.com/v1_1/dzsrg1xlh/image/upload";
// const UPLOAD_PRESET = "disease_image";
// const ReportScreen = ({ route }) => {
//   const { detections, imageUrl } = route.params;
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [reportDate, setReportDate] = useState("");

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       if (currentUser) {
//         fetchUserDetails(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     const now = new Date();
//     const formattedDate = now.toLocaleDateString();
//     const formattedTime = now.toLocaleTimeString();
//     setReportDate(`${formattedDate} | ${formattedTime}`);

//     return () => unsubscribe();
//   }, []);

//   const fetchUserDetails = async (email) => {
//     setLoading(true);
//     try {
//       doc(collection(db, "users", userId, "reports"))
//       const q = query(usersRef, where("email", "===", email));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         setUserData(querySnapshot.docs[0].data());
//       } else {
//         console.warn("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const uploadImageToCloudinary = async (uri) => {
//     try {
//       const formData = new FormData();
//       formData.append("file", { uri, type: "image/jpeg", name: "report.jpg" });
//       formData.append("upload_preset", UPLOAD_PRESET);
      
//       const response = await fetch(CLOUDINARY_URL, {
//         method: "POST",
//         body: formData,
//       });

//       const data = await response.json();
//       return data.secure_url;
//     } catch (error) {
//       console.error("Error uploading image to Cloudinary:", error);
//       Alert.alert("Error", "Image upload failed.");
//       return null;
//     }
//   };

//   const saveReport = async () => {
//     if (!auth.currentUser) {
//       Alert.alert("Error", "You must be logged in to save reports.");
//       return;
//     }
  
//     setLoading(true);
//     try {
//       const cloudinaryUrl = await uploadImageToCloudinary(imageUrl);
//       if (!cloudinaryUrl) return;
  
//       const userEmail = auth.currentUser.email;
//       const usersRef = collection(db, "users");
  
//       // Find the user document where email matches
//       const q = query(usersRef, where("email", "==", userEmail));
//       const querySnapshot = await getDocs(q);
  
//       if (querySnapshot.empty) {
//         Alert.alert("Error", "User document not found.");
//         setLoading(false);
//         return;
//       }
  
//       // Get the document ID of the matched user
//       const userDoc = querySnapshot.docs[0]; 
//       const userDocRef = doc(db, "users", userDoc.id);
//       const reportsCollectionRef = collection(userDocRef, "reports");
  
//       // Create the new report
//       const newReport = {
//         date: reportDate,
//         detections,
//         imageUrl: cloudinaryUrl,
//       };
  
//       await addDoc(reportsCollectionRef, newReport);
//       Alert.alert("Success", "Report saved successfully!");
//     } catch (error) {
//       console.error("Error saving report:", error);
//       Alert.alert("Error", "Failed to save the report.");
//     } finally {
//       setLoading(false);
//     }
//   };
  

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }
//   const classMapping = {
//     "1": "Ulcer",
//     "2": "Tooth Discoloration",
//     "3": "Gingivitis",
//     "caries":"Caries"
//   };
//   return (
//     <ScrollView style={styles.container}>
//       <Text style={styles.title}>Detection Report</Text>
  
//       {userData && (
//         <View style={styles.userInfo}>
//           <Text style={styles.userText}>
//             <MaterialIcons name="person" size={18} color="#0288D1" /> {userData.name}
//           </Text>
//           <Text style={styles.userText}>
//             <MaterialIcons name="calendar-today" size={18} color="#0288D1" /> {reportDate}
//           </Text>
//         </View>
//       )}
  
//       <Image source={{ uri: imageUrl }} style={styles.image} />
  
//       <View style={styles.reportContainer}>
//         <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
//         {detections.length > 0 ? (
//           detections.map((det, index) => {
//             const condition = classMapping[det.class] || "Unknown Condition";
//             return (
//               <Text key={index} style={styles.detectionText}>
//                 🦷 {condition} (Confidence: {det.confidence.toFixed(2)*100}%)
//               </Text>
//             );
//           })
//         ) : (
//           <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
//         )}
//       </View>
  
//       {/* Save Report Button */}
//       <Button title="Save Report" onPress={saveReport} color="#0288D1" />
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#F9FAFB",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     textAlign: "center",
//     marginBottom: 10,
//     color: "#0288D1",
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   userInfo: {
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 10,
//     marginBottom: 10,
//     alignItems: "center",
//   },
//   userText: {
//     fontSize: 16,
//     fontWeight: "bold",
//     color: "#01579B",
//     marginBottom: 5,
//   },
//   image: {
//     width: "100%",
//     height: 250,
//     borderRadius: 10,
//     marginBottom: 20,
//   },
// });

// export default ReportScreen;




import React, { useEffect, useState } from "react";
import { 
  View, Text, Image, StyleSheet, ScrollView, ActivityIndicator, Button, Alert 
} from "react-native";
import { auth, db } from "../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { collection, doc, addDoc, getDocs, query, where } from "firebase/firestore";
import { MaterialIcons } from "@expo/vector-icons";

const CLOUDINARY_URL = "https://api.cloudinary.com/v1_1/dzsrg1xlh/image/upload";
const UPLOAD_PRESET = "disease_image";

const ReportScreen = ({ route }) => {
  const { detections, imageUri } = route.params;
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reportDate, setReportDate] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        fetchUserDetails(currentUser.email);
      } else {
        setLoading(false);
      }
    });

    const now = new Date();
    setReportDate(`${now.toLocaleDateString()} | ${now.toLocaleTimeString()}`);

    return () => unsubscribe();
  }, []);

  const fetchUserDetails = async (email) => {
    setLoading(true);
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("email", "==", email));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        setUserData(querySnapshot.docs[0].data());
      } else {
        console.warn("User not found in Firestore");
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setLoading(false);
    }
  };

  const uploadImageToCloudinary = async (uri) => {
    try {
      const formData = new FormData();
      formData.append("file", { uri, type: "image/jpeg", name: "report.jpg" });
      formData.append("upload_preset", UPLOAD_PRESET);

      const response = await fetch(CLOUDINARY_URL, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      return data.secure_url;
    } catch (error) {
      console.error("Error uploading image to Cloudinary:", error);
      Alert.alert("Error", "Image upload failed.");
      return null;
    }
  };

  const saveReport = async () => {
    if (!auth.currentUser) {
      Alert.alert("Error", "You must be logged in to save reports.");
      return;
    }
  
    setLoading(true);
    try {
      const cloudinaryUrl = await uploadImageToCloudinary(imageUri);
      if (!cloudinaryUrl) return;
  
      const userEmail = auth.currentUser.email;
      const usersRef = collection(db, "users");
  
      // Find the user document where email matches
      const q = query(usersRef, where("email", "==", userEmail));
      const querySnapshot = await getDocs(q);
  
      if (querySnapshot.empty) {
        Alert.alert("Error", "User document not found.");
        setLoading(false);
        return;
      }
  
      // Get the document ID of the matched user
      const userDoc = querySnapshot.docs[0];
      const userDocRef = doc(db, "users", userDoc.id);
      
      // Reference the reports subcollection
      const reportsCollectionRef = collection(userDocRef, "reports");
  
      // Create the new report document
      const newReport = {
        date: reportDate,
        detections,
        imageUrl: cloudinaryUrl,
      };
  
      await addDoc(reportsCollectionRef, newReport);
      Alert.alert("Success", "Report saved successfully!");
    } catch (error) {
      console.error("Error saving report:", error);
      Alert.alert("Error", "Failed to save the report.");
    } finally {
      setLoading(false);
    }
  };
  
  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  const classMapping = {
    "1": "Ulcer",
    "2": "Tooth Discoloration",
    "3": "Gingivitis",
    "caries": "Caries"
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Detection Report</Text>

      {userData && (
        <View style={styles.userInfo}>
          <Text style={styles.userText}>
            <MaterialIcons name="person" size={18} color="#0288D1" /> {userData.name}
          </Text>
          <Text style={styles.userText}>
            <MaterialIcons name="calendar-today" size={18} color="#0288D1" /> {reportDate}
          </Text>
        </View>
      )}

      <Image source={{ uri: imageUri }} style={styles.image} />

      <View style={styles.reportContainer}>
        <Text style={styles.subtitle}>Detected Tooth Problems:</Text>
        {detections.length > 0 ? (
          detections.map((det, index) => {
            const condition = classMapping[det.class] || "Unknown Condition";
            return (
              <Text key={index} style={styles.detectionText}>
                🦷 {condition} (Confidence: {(det.confidence * 100).toFixed(2)}%)
              </Text>
            );
          })
        ) : (
          <Text style={styles.noDetectionText}>No issues detected! 🎉</Text>
        )}
      </View>

      {/* Save Report Button */}
      <Button title="Save Report" onPress={saveReport} color="#0288D1" />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#F9FAFB",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
    color: "#0288D1",
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  userInfo: {
    backgroundColor: "#E3F2FD",
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: "center",
  },
  userText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#01579B",
    marginBottom: 5,
  },
  image: {
    width: "100%",
    height: 250,
    borderRadius: 10,
    marginBottom: 20,
  },
  reportContainer: {
    backgroundColor: "#E3F2FD",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#0288D1",
    marginBottom: 10,
  },
  detectionText: {
    fontSize: 16,
    color: "#01579B",
    marginBottom: 5,
  },
  noDetectionText: {
    fontSize: 16,
    color: "green",
    fontWeight: "bold",
  },
});

export default ReportScreen;
