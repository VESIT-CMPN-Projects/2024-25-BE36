// import React from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Image,
// } from "react-native";
// import BottomNavBar from "./BottomNavBar";
// // import DetectionTypesScroller from "./DetectionTypesScroller";
// // import DentistrySpecialistsScroller from "./DentistrySpecialistsScroller";
// import TopBar from "./TopBar";
// import { SafeAreaView } from "react-native-safe-area-context";

// const HomePage = ({ navigation }) => {
//   const handleChatbotPress = () => {
//     navigation.navigate("Chatbot");
//   };

//   return (
//     <View style={styles.container}>
//       <TopBar onProfilePress={() => navigation.navigate("ProfileScreen")} />

//       <ScrollView contentContainerStyle={styles.contentContainer}>
//         {/* Chatbot Banner */}
//         <TouchableOpacity style={styles.banner} onPress={handleChatbotPress}>
//           <Image
//             source={{
//               uri: "https://cdn-icons-png.flaticon.com/512/4712/4712038.png",
//             }}
//             style={styles.bannerIcon}
//           />
//           <View style={styles.bannerTextContainer}>
//             <Text style={styles.bannerTitle}>Use the Chatbot</Text>
//             <Text style={styles.bannerSubtitle}>
//               Get quick answers for basic dental problems.
//             </Text>
//           </View>
//         </TouchableOpacity>
//         <TouchableOpacity
//           style={styles.chatButton}
//           onPress={() => navigation.navigate("ChatsListScreen")}
//         >
//           <Image
//             source={{
//               uri: "https://cdn-icons-png.flaticon.com/512/1384/1384023.png",
//             }}
//             style={styles.chatIcon}
//           />
//           <View style={styles.bannerTextContainer}>
//             <Text style={styles.bannerTitle}>Chat with a Dentist</Text>
//             <Text style={styles.bannerSubtitle}>
//               Get expert advice from professionals.
//             </Text>
//           </View>
//         </TouchableOpacity>
//       </ScrollView>

//       <BottomNavBar navigation={navigation} />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#EAF4FC",
//     paddingTop: 60,
//     marginTop: 15,
//   },
//   contentContainer: {
//     margin: 15,
//     paddingVertical: 20,
//     paddingHorizontal: 15,
//     alignItems: "flex-start",
//   },
//   banner: {
//     flexDirection: "row",
//     backgroundColor: "#0288D1", // Blue background
//     borderRadius: 12,
//     padding: 15,
//     alignItems: "center",
//     justifyContent: "flex-start",
//     marginBottom: 20,
//     marginTop: 60,
//     width: "100%",
//     elevation: 4,
//     height: 150,
//   },
//   bannerIcon: {
//     width: 50,
//     height: 50,
//     marginRight: 15,
//   },
//   bannerTextContainer: {
//     flex: 1,
//   },
//   bannerTitle: {
//     fontSize: 18,
//     fontWeight: "bold",
//     color: "#FFF",
//   },
//   bannerSubtitle: {
//     fontSize: 14,
//     color: "#E3F2FD",
//   },
//   chatButton: {
//     flexDirection: "row",
//     backgroundColor: "#4CAF50", // Green color for chats
//     borderRadius: 12,
//     padding: 15,
//     alignItems: "center",
//     justifyContent: "flex-start",
//     marginBottom: 20,
//     width: "100%",
//     elevation: 4,
//     height: 150,
//   },
//   chatIcon: {
//     width: 50,
//     height: 50,
//     marginRight: 15,
//   },
// });

// export default HomePage;




import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from "react-native";
import BottomNavBar from "./BottomNavBar";
import TopBar from "./TopBar";
// import YoloLogo from "../assets/yolov8.png";

const HomePage = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <TopBar onProfilePress={() => navigation.navigate("ProfileScreen")} />

      <ScrollView contentContainerStyle={styles.contentContainer}>
        {/* Chatbot Banner */}
        <TouchableOpacity
          style={styles.banner}
          onPress={() => navigation.navigate("Chatbot")}
        >
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/4712/4712038.png",
            }}
            style={styles.bannerIcon}
          />
          <View style={styles.bannerTextContainer}>
            <Text style={styles.bannerTitle}>Use the Chatbot</Text>
            <Text style={styles.bannerSubtitle}>
              Get quick answers for basic dental problems.
            </Text>
          </View>
        </TouchableOpacity>

        {/* Chat with a Dentist */}
        <TouchableOpacity
          style={styles.chatButton}
          onPress={() => navigation.navigate("ChatsListScreen")}
        >
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/1384/1384023.png",
            }}
            style={styles.chatIcon}
          />
          <View style={styles.bannerTextContainer}>
            <Text style={styles.bannerTitle}>Chat with a Dentist</Text>
            <Text style={styles.bannerSubtitle}>
              Get expert advice from professionals.
            </Text>
          </View>
        </TouchableOpacity>

        {/* Navigate to TFLite Upload Page */}
        {/* <TouchableOpacity
          style={styles.tfliteButton}
          onPress={() => navigation.navigate("TFLiteUpload")}
        >
          <Image
            source={{
              uri: "https://cdn-icons-png.flaticon.com/512/1828/1828774.png",
            }}
            style={styles.chatIcon}
          />
          <View style={styles.bannerTextContainer}>
            <Text style={styles.bannerTitle}>Detect Using YoloV8</Text>
            <Text style={styles.bannerSubtitle}>
              Upload an image and detect objects using the TFLite model.
            </Text>
          </View>
        </TouchableOpacity> */}
      </ScrollView>

      <BottomNavBar navigation={navigation} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#EAF4FC",
    paddingTop: 60,
    marginTop: 15,
  },
  contentContainer: {
    margin: 15,
    paddingVertical: 20,
    paddingHorizontal: 15,
    alignItems: "flex-start",
  },
  banner: {
    flexDirection: "row",
    backgroundColor: "#0288D1",
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
    justifyContent: "flex-start",
    marginBottom: 20,
    marginTop: 60,
    width: "100%",
    elevation: 4,
    height: 150,
  },
  chatButton: {
    flexDirection: "row",
    backgroundColor: "#4CAF50",
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
    justifyContent: "flex-start",
    marginBottom: 20,
    width: "100%",
    elevation: 4,
    height: 150,
  },
  tfliteButton: {
    flexDirection: "row",
    backgroundColor: "#FF9800",
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
    justifyContent: "flex-start",
    marginBottom: 20,
    width: "100%",
    elevation: 4,
    height: 150,
  },
  bannerIcon: {
    width: 50,
    height: 50,
    marginRight: 15,
  },
  chatIcon: {
    width: 50,
    height: 50,
    marginRight: 15,
  },
  bannerTextContainer: {
    flex: 1,
  },
  bannerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFF",
  },
  bannerSubtitle: {
    fontSize: 14,
    color: "#E3F2FD",
  },
});

export default HomePage;
