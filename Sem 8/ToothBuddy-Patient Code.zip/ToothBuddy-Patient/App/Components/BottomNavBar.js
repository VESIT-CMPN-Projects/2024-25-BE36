// BottomNavBar.js
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/MaterialCommunityIcons"; // Importing MaterialCommunityIcons

const BottomNavBar = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.navigate("Home")}
        style={styles.tab}
      >
        <Icon name="home" size={24} color="white" />
        <Text style={styles.tabText}>Home</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("ImageUpload")}
        style={styles.tab}
      >
        <Icon name="barcode-scan" size={24} color="white" />
        <Text style={styles.tabText}>Scan v11</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("Dentists")}
        style={styles.tab}
      >
        <Icon name="doctor" size={24} color="white" />
        <Text style={styles.tabText}>Doctors</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#0288D1",
    paddingVertical: 15,
    position: "absolute",
    bottom: 20, // Lift the navbar 20 pixels above the bottom
    left: 20,
    right: 20,
    borderRadius: 30, // Curved edges
    zIndex: 1,
    elevation: 5, // For Android shadow
    shadowColor: "#000", // For iOS shadow
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  tab: {
    alignItems: "center",
  },
  tabText: {
    color: "white",
    fontSize: 12,
    marginTop: 4,
  },
});

export default BottomNavBar;
