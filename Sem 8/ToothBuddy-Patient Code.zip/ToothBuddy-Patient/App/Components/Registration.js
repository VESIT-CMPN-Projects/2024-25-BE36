import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, Alert, StyleSheet, KeyboardAvoidingView, ScrollView, Platform, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { collection, doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebaseConfig';
// import { useAuth } from '../userContext';

const Registration = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [dob, setDob] = useState('');
  const [mobile, setMobile] = useState('');
  const [oralProblems, setOralProblems] = useState('');
  // const { setUserEmail } = useAuth();

  const handleLoginUser = () => {
    navigation.navigate('Login');
  };

  const handleRegister = async () => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      await setDoc(doc(collection(db, 'users'), user.uid), {
        name,
        email,
        gender,
        dob,
        mobile,
        oralProblems,
      });
      // setUserEmail(email);
      Alert.alert('Success', 'Registration Successful!');
      navigation.replace('Home');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <ScrollView contentContainerStyle={styles.scrollView}>
          <View style={styles.card}>
            <Text style={styles.title}>Register</Text>
            <TextInput placeholder='Name' style={styles.input} onChangeText={setName} />
            <TextInput placeholder='Email' style={styles.input} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
            <TextInput placeholder='Gender' style={styles.input} onChangeText={setGender} />
            <TextInput placeholder='Date of Birth' style={styles.input} onChangeText={setDob} />
            <TextInput placeholder='Mobile' style={styles.input} onChangeText={setMobile} keyboardType="phone-pad" />
            <TextInput placeholder='Oral Problems' style={styles.input} onChangeText={setOralProblems} />
            <TextInput placeholder='Password' style={styles.input} secureTextEntry onChangeText={setPassword} />

            <TouchableOpacity style={styles.button} onPress={handleRegister}>
              <Text style={styles.buttonText}>Register</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.registerLink} onPress={handleLoginUser}>
              <Text style={styles.registerText}>Already have an account? <Text style={styles.boldText}>Login</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f8ff", // Light sky blue background
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  card: {
    width: "100%",
    backgroundColor: "#ffffff",
    padding: 25,
    borderRadius: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 5, // Shadow for Android
    alignItems: "center",
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },
  input: {
    width: "100%",
    height: 50,
    backgroundColor: "#f9f9f9",
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#ccc",
  },
  button: {
    backgroundColor: "#3498db", // Light blue
    paddingVertical: 14,
    borderRadius: 10,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#fff",
  },
  registerLink: {
    marginTop: 15,
  },
  registerText: {
    fontSize: 14,
    color: "#3498db",
  },
  boldText: {
    fontWeight: "bold",
  },
});

export default Registration;
