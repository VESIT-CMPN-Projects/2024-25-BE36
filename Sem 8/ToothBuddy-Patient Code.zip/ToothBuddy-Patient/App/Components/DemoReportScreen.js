// import React, { useEffect, useState } from "react";
// import { View, Text, ActivityIndicator, StyleSheet, Image, ScrollView } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, query, where, getDocs } from "firebase/firestore";
// import { MaterialIcons } from "@expo/vector-icons";

// const DemoReportScreen = () => {
//   const [user, setUser] = useState(null);
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       setUser(currentUser);
//       if (currentUser) {
//         fetchUserDetails(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return () => unsubscribe();
//   }, []);

//   const fetchUserDetails = async (email) => {
//     if (!email) {
//       console.error("Email is undefined. Cannot fetch user details.");
//       return;
//     }

//     setLoading(true);
//     try {
//       const usersRef = collection(db, "users");
//       const q = query(usersRef, where("email", "==", email));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         const userDoc = querySnapshot.docs[0];
//         setUserData(userDoc.data());
//       } else {
//         console.warn("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       {userData ? (
//         <View style={styles.card}>
//           <Text style={styles.heading}>🦷 Dental Report</Text>
//           <Image
//             source={{ uri: "https://via.placeholder.com/300" }} // Replace with actual disease detection image URL
//             style={styles.image}
//           />
//           <View style={styles.infoRow}>
//             <MaterialIcons name="person" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.name}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="email" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.email}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="calendar-today" size={24} color="#0288D1" />
//             <Text style={styles.text}>{new Date().toLocaleDateString()}</Text>
//           </View>
//           <Text style={styles.subHeading}>Detected Conditions:</Text>
//           <View style={styles.conditionBox}>
//             <Text style={styles.conditionText}>1. Cavities (Tooth Decay) - Medium Severity</Text>
//           </View>
//           <View style={styles.conditionBox}>
//             <Text style={styles.conditionText}>2. Gingivitis - Mild Inflammation</Text>
//           </View>
//           <View style={styles.conditionBox}>
//             <Text style={styles.conditionText}>3. Plaque Buildup - Requires Cleaning</Text>
//           </View>
//         </View>
//       ) : (
//         <Text style={styles.noDataText}>User details not found.</Text>
//       )}
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flexGrow: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#F5F5F5",
//     padding: 20,
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   card: {
//     backgroundColor: "#FFFFFF",
//     padding: 20,
//     borderRadius: 12,
//     shadowColor: "#000",
//     shadowOffset: { width: 0, height: 3 },
//     shadowOpacity: 0.2,
//     shadowRadius: 4,
//     elevation: 6,
//     width: "90%",
//     alignItems: "center",
//   },
//   heading: {
//     fontSize: 24,
//     fontWeight: "bold",
//     marginBottom: 15,
//     textAlign: "center",
//     color: "#0288D1",
//   },
//   image: {
//     width: 300,
//     height: 200,
//     borderRadius: 10,
//     marginBottom: 15,
//   },
//   infoRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginBottom: 12,
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 8,
//     width: "100%",
//   },
//   text: {
//     fontSize: 18,
//     marginLeft: 10,
//     color: "#333",
//   },
//   subHeading: {
//     fontSize: 20,
//     fontWeight: "bold",
//     marginTop: 15,
//     color: "#0288D1",
//   },
//   conditionBox: {
//     backgroundColor: "#FFEB3B",
//     padding: 10,
//     borderRadius: 8,
//     marginVertical: 5,
//     width: "100%",
//   },
//   conditionText: {
//     fontSize: 16,
//     color: "#333",
//   },
//   noDataText: {
//     fontSize: 18,
//     color: "#888",
//   },
// });

// export default DemoReportScreen;


import React, { useEffect, useState } from "react";
import { View, Text, ActivityIndicator, StyleSheet, Image, ScrollView } from "react-native";
import { auth, db } from "../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { collection, query, where, getDocs } from "firebase/firestore";
import { MaterialIcons } from "@expo/vector-icons";

const DemoReportScreen = () => {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        fetchUserDetails(currentUser.email);
      } else {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const fetchUserDetails = async (email) => {
    if (!email) {
      console.error("Email is undefined. Cannot fetch user details.");
      return;
    }

    setLoading(true);
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("email", "==", email));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const userDoc = querySnapshot.docs[0];
        setUserData(userDoc.data());
      } else {
        console.warn("User not found in Firestore");
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {userData ? (
        <View style={styles.card}>
          <Text style={styles.heading}>🦷 Dental Report</Text>
          <Image
            source={{ uri: userData.imageUrl || "https://via.placeholder.com/300" }}
            style={styles.image}
          />
          <View style={styles.infoRow}>
            <MaterialIcons name="person" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.name}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="email" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.email}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="calendar-today" size={24} color="#0288D1" />
            <Text style={styles.text}>{new Date().toLocaleDateString()}</Text>
          </View>
          <Text style={styles.subHeading}>Detected Conditions:</Text>
          {userData.conditions && userData.conditions.length > 0 ? (
            userData.conditions.map((condition, index) => (
              <View key={index} style={styles.conditionBox}>
                <Text style={styles.conditionText}>{`${index + 1}. ${condition.name} - ${condition.severity}`}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.noConditionsText}>No conditions detected.</Text>
          )}
        </View>
      ) : (
        <Text style={styles.noDataText}>User details not found.</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
    padding: 20,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  card: {
    backgroundColor: "#FFFFFF",
    padding: 20,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 6,
    width: "90%",
    alignItems: "center",
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
    color: "#0288D1",
  },
  image: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    backgroundColor: "#E3F2FD",
    padding: 10,
    borderRadius: 8,
    width: "100%",
  },
  text: {
    fontSize: 18,
    marginLeft: 10,
    color: "#333",
  },
  subHeading: {
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 15,
    color: "#0288D1",
  },
  conditionBox: {
    backgroundColor: "#FFEB3B",
    padding: 10,
    borderRadius: 8,
    marginVertical: 5,
    width: "100%",
  },
  conditionText: {
    fontSize: 16,
    color: "#333",
  },
  noConditionsText: {
    fontSize: 16,
    color: "#777",
    fontStyle: "italic",
  },
  noDataText: {
    fontSize: 18,
    color: "#888",
  },
});

export default DemoReportScreen;
