// import React, { useEffect, useState } from "react";
// import { View, Text, ActivityIndicator, StyleSheet } from "react-native";
// import { auth, db } from "../firebaseConfig";
// import { onAuthStateChanged } from "firebase/auth";
// import { collection, query, where, getDocs } from "firebase/firestore";
// import { MaterialIcons } from "@expo/vector-icons"; // Icons for better UI

// const ProfileScreen = () => {
//   const [user, setUser] = useState(null);
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
//       setUser(currentUser);
//       if (currentUser) {
//         fetchUserDetails(currentUser.email);
//       } else {
//         setLoading(false);
//       }
//     });

//     return () => unsubscribe();
//   }, []);

//   const fetchUserDetails = async (email) => {
//     if (!email) {
//       console.error("Email is undefined. Cannot fetch user details.");
//       return;
//     }

//     setLoading(true);
//     try {
//       const usersRef = collection(db, "users");
//       const q = query(usersRef, where("email", "==", email));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         const userDoc = querySnapshot.docs[0];
//         setUserData(userDoc.data());
//       } else {
//         console.warn("User not found in Firestore");
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loaderContainer}>
//         <ActivityIndicator size="large" color="#0288D1" />
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       {userData ? (
//         <View style={styles.card}>
//           <Text style={styles.heading}>👤 Profile</Text>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="person" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.name}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="email" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.email}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="cake" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.dob}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="wc" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.gender}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="phone" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.mobile}</Text>
//           </View>
//           <View style={styles.infoRow}>
//             <MaterialIcons name="healing" size={24} color="#0288D1" />
//             <Text style={styles.text}>{userData.oralProblems}</Text>
//           </View>
//         </View>
//       ) : (
//         <Text style={styles.noDataText}>User details not found.</Text>
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#F5F5F5",
//     padding: 20,
//   },
//   loaderContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   card: {
//     backgroundColor: "#FFFFFF",
//     padding: 20,
//     borderRadius: 12,
//     shadowColor: "#000",
//     shadowOffset: { width: 0, height: 3 },
//     shadowOpacity: 0.2,
//     shadowRadius: 4,
//     elevation: 6,
//     width: "90%",
//   },
//   heading: {
//     fontSize: 24,
//     fontWeight: "bold",
//     marginBottom: 15,
//     textAlign: "center",
//     color: "#0288D1",
//   },
//   infoRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginBottom: 12,
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 8,
//   },
//   text: {
//     fontSize: 18,
//     marginLeft: 10,
//     color: "#333",
//   },
//   noDataText: {
//     fontSize: 18,
//     color: "#888",
//   },
// });

// export default ProfileScreen;


import React, { useEffect, useState } from "react";
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from "react-native";
import { auth, db } from "../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { collection, query, where, getDocs } from "firebase/firestore";
import { MaterialIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native"; // For navigation

const ProfileScreen = () => {
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation(); // Hook for navigation

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        fetchUserDetails(currentUser.email);
      } else {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const fetchUserDetails = async (email) => {
    if (!email) {
      console.error("Email is undefined. Cannot fetch user details.");
      return;
    }

    setLoading(true);
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("email", "==", email));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const userDoc = querySnapshot.docs[0];
        setUserData(userDoc.data());
      } else {
        console.warn("User not found in Firestore");
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {userData ? (
        <>
          <Text style={styles.heading}>👤 Profile</Text>
          <View style={styles.infoRow}>
            <MaterialIcons name="person" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.name}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="email" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.email}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="cake" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.dob}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="wc" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.gender}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="phone" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.mobile}</Text>
          </View>
          <View style={styles.infoRow}>
            <MaterialIcons name="healing" size={24} color="#0288D1" />
            <Text style={styles.text}>{userData.oralProblems}</Text>
          </View>

          {/* View Reports Button */}
          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate("Reports")}
          >
            <Text style={styles.buttonText}>View Reports</Text>
          </TouchableOpacity>
        </>
      ) : (
        <Text style={styles.noDataText}>User details not found.</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F5F5",
    padding: 20,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
    color: "#0288D1",
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
    backgroundColor: "#E3F2FD",
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 10,
    width: "100%",
  },
  text: {
    fontSize: 18,
    marginLeft: 12,
    color: "#333",
    flexShrink: 1,
  },
  button: {
    marginTop: 20,
    backgroundColor: "#0288D1",
    padding: 12,
    borderRadius: 10,
    width: "80%",
    alignItems: "center",
  },
  buttonText: {
    color: "#FFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  noDataText: {
    fontSize: 18,
    color: "#888",
    textAlign: "center",
  },
});

export default ProfileScreen;
