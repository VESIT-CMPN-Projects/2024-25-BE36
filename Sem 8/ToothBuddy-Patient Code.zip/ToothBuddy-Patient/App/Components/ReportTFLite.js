import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Button,
  Alert,
} from "react-native";
import { auth, db } from "../firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import {
  collection,
  doc,
  addDoc,
  getDocs,
  query,
  where,
} from "firebase/firestore";
import { MaterialIcons } from "@expo/vector-icons";

const ReportTFLite = ({ route }) => {
  const { detections, imageUri } = route.params;
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reportDate, setReportDate] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        fetchUserDetails(currentUser.email);
      } else {
        setLoading(false);
      }
    });

    const now = new Date();
    const formattedDate = now.toLocaleDateString();
    const formattedTime = now.toLocaleTimeString();
    setReportDate(`${formattedDate} | ${formattedTime}`);

    return () => unsubscribe();
  }, []);

  const fetchUserDetails = async (email) => {
    setLoading(true);
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("email", "==", email));
      const querySnapshot = await getDocs(q);
      if (!querySnapshot.empty) {
        setUserData(querySnapshot.docs[0].data());
      } else {
        console.warn("User not found in Firestore");
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveReport = async () => {
    if (!auth.currentUser) {
      Alert.alert("Error", "You must be logged in to save reports.");
      return;
    }

    try {
      const userId = auth.currentUser.uid;
      const userDocRef = doc(db, "users", userId);
      const reportsCollectionRef = collection(userDocRef, "reports");

      const newReport = {
        date: reportDate,
        detections: detections,
        imageUri: imageUri,
      };

      await addDoc(reportsCollectionRef, newReport);
      Alert.alert("Success", "Report saved successfully!");
    } catch (error) {
      console.error("Error saving report:", error);
      Alert.alert("Error", "Failed to save the report.");
    }
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#0288D1" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>TFLite Detection Report</Text>

      {userData && (
        <View style={styles.userInfo}>
          <Text style={styles.userText}>
            <MaterialIcons name="person" size={18} color="#0288D1" />{" "}
            {userData.name}
          </Text>
          <Text style={styles.userText}>
            <MaterialIcons name="calendar-today" size={18} color="#0288D1" />{" "}
            {reportDate}
          </Text>
        </View>
      )}

      <Image source={{ uri: imageUri }} style={styles.image} />

      <View style={styles.reportContainer}>
        <Text style={styles.subtitle}>Detections:</Text>
        {detections.length > 0 ? (
          detections.map((detection, index) => (
            <Text key={index} style={styles.detectionText}>
              {detection.class} - Confidence:{" "}
              {(detection.confidence * 100).toFixed(2)}%
            </Text>
          ))
        ) : (
          <Text style={styles.noDetectionText}>No detections found.</Text>
        )}
      </View>

      <Button title="Save Report" onPress={saveReport} color="#0288D1" />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: "#EAF4FC", flex: 1 },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#0288D1",
    textAlign: "center",
    marginBottom: 20,
  },
  userInfo: { alignItems: "center", marginBottom: 20 },
  userText: { fontSize: 16, fontWeight: "bold", color: "#333" },
  image: {
    width: 300,
    height: 300,
    alignSelf: "center",
    borderRadius: 10,
    marginBottom: 20,
  },
  reportContainer: {
    padding: 15,
    backgroundColor: "#fff",
    borderRadius: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#0288D1",
    marginBottom: 10,
  },
  detectionText: { fontSize: 16, color: "#333", marginBottom: 5 },
  noDetectionText: { fontSize: 16, color: "#777", textAlign: "center" },
  loaderContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
});

export default ReportTFLite;
