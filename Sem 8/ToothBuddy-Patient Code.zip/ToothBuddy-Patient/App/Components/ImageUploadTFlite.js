// import React, { useState } from "react";
// import { View, ActivityIndicator, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUploadTFLite = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const navigation = useNavigation();

//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(",")[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (!permissionResult.granted) {
//       Alert.alert("Permission Required", "Please allow access to your media library.");
//       return;
//     }
    
//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });
    
//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     setLoading(true);
//     const base64Image = await convertToBase64(uri);
  
//     try {
//       const response = await fetch("http://192.168.29.249:5000/yolov8", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ image: base64Image }),
//       });
  
//       const data = await response.json();
//       console.log("Response from server:", data);
  
//       if (Array.isArray(data) && data.length > 0 && data[0].predictions) {
//         const predictions = data[0].predictions.predictions;
        
//         if (predictions.length > 0) {
//           const formattedPredictions = predictions.map(pred => ({
//             class: pred.class,
//             confidence: pred.confidence,
//           }));
  
//           navigation.navigate("Report", { detections: formattedPredictions, imageUri: uri });
//         } else {
//           Alert.alert("No Detections", "No objects were detected in the image.");
//         }
//       } else {
//         Alert.alert("Error", "Invalid response structure from the model.");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       Alert.alert("Upload Failed", "An error occurred while processing your request.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for TFLite Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
//         <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
//       </TouchableOpacity>
//       {selectedImage && (
//         <>
//           <TouchableOpacity style={styles.button} onPress={() => uploadImage(selectedImage)} disabled={loading}>
//             <Text style={styles.buttonText}>{loading ? "Detecting..." : "Detect Using TFLite"}</Text>
//           </TouchableOpacity>
//           <Image source={{ uri: selectedImage }} style={styles.image} />
//         </>
//       )}
//       {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 8,
//     width: "80%",
//     alignItems: "center",
//     marginTop: 10,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUploadTFLite;



// import React, { useState } from "react";
// import { View, ActivityIndicator, Image, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUploadTFLite = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [detections, setDetections] = useState([]);
//   const navigation = useNavigation();

//   const convertToBase64 = async (uri) => {
//     const response = await fetch(uri);
//     const blob = await response.blob();
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onloadend = () => resolve(reader.result.split(",")[1]);
//       reader.onerror = reject;
//       reader.readAsDataURL(blob);
//     });
//   };

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (!permissionResult.granted) {
//       Alert.alert("Permission Required", "Please allow access to your media library.");
//       return;
//     }
    
//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });
    
//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//     }
//   };

//   const uploadImage = async (uri) => {
//     setLoading(true);
//     setDetections([]);
//     const base64Image = await convertToBase64(uri);
  
//     try {
//       const response = await fetch("http://192.168.29.249:5000/yolov8", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ image: base64Image }),
//       });
  
//       const data = await response.json();
//       console.log("Response from server:", data);
  
//       if (Array.isArray(data) && data.length > 0 && data[0].predictions) {
//         const predictions = data[0].predictions.predictions;
        
//         if (predictions.length > 0) {
//           setDetections(predictions);
//         } else {
//           Alert.alert("No Detections", "No objects were detected in the image.");
//         }
//       } else {
//         Alert.alert("Error", "Invalid response structure from the model.");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       Alert.alert("Upload Failed", "An error occurred while processing your request.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>TFLite Detection Report</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
//         <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
//       </TouchableOpacity>
//       {selectedImage && (
//         <>
//           <Image source={{ uri: selectedImage }} style={styles.image} />
//           <TouchableOpacity style={styles.button} onPress={() => uploadImage(selectedImage)} disabled={loading}>
//             <Text style={styles.buttonText}>{loading ? "Detecting..." : "Detect Using TFLite"}</Text>
//           </TouchableOpacity>
//         </>
//       )}
//       {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
//       {detections.length > 0 && (
//         <View style={styles.reportContainer}>
//           <Text style={styles.reportTitle}>Detection Report</Text>
//           {detections.map((item, index) => (
//             <View key={index} style={styles.detectionItem}>
//               <Text style={styles.detectionText}>Class: {item.class}</Text>
//               <Text style={styles.detectionText}>Confidence: {(item.confidence * 100).toFixed(2)}%</Text>
//             </View>
//           ))}
//         </View>
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 8,
//     width: "80%",
//     alignItems: "center",
//     marginTop: 10,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
//   reportContainer: {
//     marginTop: 20,
//     padding: 10,
//     backgroundColor: "#fff",
//     borderRadius: 10,
//     width: "90%",
//     elevation: 5,
//   },
//   reportTitle: {
//     fontSize: 20,
//     fontWeight: "bold",
//     textAlign: "center",
//     color: "#0288D1",
//     marginBottom: 10,
//   },
//   detectionItem: {
//     backgroundColor: "#E3F2FD",
//     padding: 10,
//     borderRadius: 5,
//     marginVertical: 5,
//   },
//   detectionText: {
//     fontSize: 16,
//     fontWeight: "bold",
//   },
// });

// export default ImageUploadTFLite;



// import React, { useState } from "react";
// import {
//   View,
//   ActivityIndicator,
//   Image,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   Alert,
// } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { useNavigation } from "@react-navigation/native";

// const ImageUploadTFLite = () => {
//   const [selectedImage, setSelectedImage] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const navigation = useNavigation();

//   const pickImage = async () => {
//     const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (!permissionResult.granted) {
//       Alert.alert("Permission Required", "Please allow access to your media library.");
//       return;
//     }

//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setSelectedImage(result.assets[0].uri);
//     }
//   };
//   const uploadImage = async (uri) => {
//     setLoading(true);  // Set loading to true before the upload starts
//     const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";
  
//     const formData = new FormData();
//     formData.append("file", {
//       uri,
//       name: "photo.jpg",
//       type,
//     });
  
//     try {
//       console.log("Uploading image...");
//       const response = await fetch("http://192.168.29.249:5001/yolov8", {
//         method: "POST",
//         body: formData,
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
  
//       if (!response.ok) {
//         throw new Error("Network response was not ok");
//       }
  
//       const data = await response.json();
//       if (data.detections) {
//         setDetections(data.detections);  // Update state
//         console.log("Detections:", data.detections);
//       } else {
//         alert("No detections found");
//       }
//     } catch (error) {
//       console.error("Error uploading image:", error);
//       alert("Error uploading image. Please try again.");
//     } finally {
//       setLoading(false);  // Set loading to false once the request is done
//     }
//   };
  
  
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Upload an Image for Detection</Text>
//       <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
//         <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
//       </TouchableOpacity>
//       {selectedImage && (
//         <>
//           <TouchableOpacity style={styles.button} onPress={() => uploadImage(selectedImage)} disabled={loading}>
//             <Text style={styles.buttonText}>{loading ? "Detecting..." : "Detect Using TFLite"}</Text>
//           </TouchableOpacity>
//           <Image source={{ uri: selectedImage }} style={styles.image} />
//         </>
//       )}
//       {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     padding: 20,
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     backgroundColor: "#EAF4FC",
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     color: "#0288D1",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#0288D1",
//     padding: 12,
//     borderRadius: 8,
//     width: "80%",
//     alignItems: "center",
//     marginTop: 10,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "bold",
//   },
//   image: {
//     width: 200,
//     height: 200,
//     marginTop: 20,
//     borderRadius: 10,
//   },
// });

// export default ImageUploadTFLite;




import React, { useState } from "react";
import {
  View,
  ActivityIndicator,
  Image,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import { useNavigation } from "@react-navigation/native";

const ImageUploadTFLite = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [detections, setDetections] = useState([]); // State for storing detections
  const navigation = useNavigation();

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert("Permission Required", "Please allow access to your media library.");
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  const uploadImage = async (uri) => {
    setLoading(true);  // Set loading to true before the upload starts
    const type = uri.endsWith(".heic") ? "image/heic" : "image/jpeg";
  
    const formData = new FormData();
    formData.append("file", {
      uri,
      name: "photo.jpg",
      type,
    });
  
    try {
      console.log("Uploading image...");
      const response = await fetch("http://192.168.29.249:5001/yolov8", {
        method: "POST",
        body: formData,
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
  
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
  
      const data = await response.json();
      if (data.detections) {
        setDetections(data.detections);  // Update state with detections
        console.log("Detections:", data.detections);
      } else {
        alert("No detections found");
      }
    } catch (error) {
      console.error("Error uploading image:", error);
      alert("Error uploading image. Please try again.");
    } finally {
      setLoading(false);  // Set loading to false once the request is done
    }
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Upload an Image for Detection</Text>
      <TouchableOpacity style={styles.button} onPress={pickImage} disabled={loading}>
        <Text style={styles.buttonText}>{loading ? "Uploading..." : "Pick an Image"}</Text>
      </TouchableOpacity>
      {selectedImage && (
        <>
          <TouchableOpacity style={styles.button} onPress={() => uploadImage(selectedImage)} disabled={loading}>
            <Text style={styles.buttonText}>{loading ? "Detecting..." : "Detect Using TFLite"}</Text>
          </TouchableOpacity>
          <Image source={{ uri: selectedImage }} style={styles.image} />
        </>
      )}
      {loading && <ActivityIndicator size="large" color="#0288D1" style={{ marginTop: 20 }} />}
      
      {/* Display detections */}
      {detections.length > 0 && (
        <View style={styles.detectionsContainer}>
          <Text style={styles.detectionsTitle}>Detections:</Text>
          {detections.map((detection, index) => (
            <Text key={index} style={styles.detectionText}>
              Class ID: {detection.class_id}, Confidence: {detection.confidence}
            </Text>
          ))}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#EAF4FC",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#0288D1",
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#0288D1",
    padding: 12,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 20,
    borderRadius: 10,
  },
  detectionsContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: "#f1f1f1",
    borderRadius: 8,
    width: "80%",
  },
  detectionsTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#0288D1",
  },
  detectionText: {
    fontSize: 16,
    color: "#333",
  },
});

export default ImageUploadTFLite;
