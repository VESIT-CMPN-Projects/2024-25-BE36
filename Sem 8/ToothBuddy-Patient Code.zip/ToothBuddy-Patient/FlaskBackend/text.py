import google.generativeai as genai

genai.configure(api_key="AIzaSyDgX-cjhF942gPSLmrVR742thetZeJjC4M")

try:
    model = genai.GenerativeModel("gemini-1.5-pro")
    response = model.generate_content("Hello!")
    print(response.text)
except Exception as e:
    print("Error:", e)
