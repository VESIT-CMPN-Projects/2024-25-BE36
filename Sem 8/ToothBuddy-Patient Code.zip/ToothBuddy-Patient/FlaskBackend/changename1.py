# import os

# def modify_file(file_path):
#     with open(file_path, 'r') as file:
#         lines = file.readlines()

#     modified_lines = []
#     for line in lines:
#         parts = line.split()
#         if parts and parts[0] == '0':  # Check if the first value is 0
#             parts[0] = '1'  # Change it to 1
#         modified_lines.append(' '.join(parts) + '\n')

#     with open(file_path, 'w') as file:
#         file.writelines(modified_lines)

# # Directory containing the 700 text files
# directory = r"C:\Users\prana\Downloads\Mahendra dataset-20250324T074357Z-001\Mahendra dataset\Ulcer\train\labels"

# # Process each text file in the directory
# for filename in os.listdir(directory):
#     if filename.endswith(".txt"):  # Ensure it's a text file
#         modify_file(os.path.join(directory, filename))

# print("Processing complete!")


# import os

# def modify_file(file_path):
#     with open(file_path, 'r') as file:
#         lines = file.readlines()

#     with open(file_path, 'w') as file:
#         for line in lines:
#             parts = line.split()
#             if parts and parts[0] == '0':  # Check if the first value is '0'
#                 parts[0] = '2'  # Change it to '1'
#             file.write(' '.join(parts) + '\n')

# # Specify the directory containing the text files
# directory = r"C:\Users\prana\Downloads\Mahendra dataset-20250324T074357Z-001\Mahendra dataset\Tooth Discoloration\train\labels"

# # Loop through all files in the directory
# for filename in os.listdir(directory):
#     if filename.endswith(".txt"):  # Ensure it's a text file
#         modify_file(os.path.join(directory, filename))

# print("All files have been updated successfully!")




# import os
# import shutil

# # Define paths
# images_folder = r"C:\Users\prana\Downloads\Mahendra dataset-20250324T074357Z-001\Mahendra dataset\Caries\train\images"  # Change to your images folder path
# text_folder = r"C:\Users\prana\Downloads\Mahendra dataset-20250324T074357Z-001\Mahendra dataset\Caries\train\labels" # Change to your text files folder path
# images_destination = r"C:\Users\prana\OneDrive\Desktop\caries selected\images"  # Folder for selected images
# text_destination = r"C:\Users\prana\OneDrive\Desktop\caries selected\labels"  # Folder for selected text files

# # Ensure destination folders exist
# os.makedirs(images_destination, exist_ok=True)
# os.makedirs(text_destination, exist_ok=True)

# # Dictionary to track the first occurrence of each numbered image
# seen_numbers = {}

# # Process images
# for filename in sorted(os.listdir(images_folder)):  # Sorting ensures first image is picked
#     if filename.endswith((".jpg", ".png")):  # Modify for other image formats if needed
#         base_number = filename.split('_')[0]  # Extract the number before '_'

#         if base_number not in seen_numbers:  # If first occurrence of this number
#             seen_numbers[base_number] = filename  # Store the image filename

#             # Copy the selected image to the images destination folder
#             img_src = os.path.join(images_folder, filename)
#             img_dest = os.path.join(images_destination, filename)
#             shutil.copy(img_src, img_dest)

#             # Find the corresponding text file in the text folder
#             txt_filename = os.path.splitext(filename)[0] + ".txt"  # Exact matching text file
#             txt_src = os.path.join(text_folder, txt_filename)

#             if os.path.exists(txt_src):  # Only copy if the exact text file exists
#                 txt_dest = os.path.join(text_destination, txt_filename)
#                 shutil.copy(txt_src, txt_dest)

# print("Selected images and corresponding text files have been copied successfully.")









# import os

# # Define paths
# images_folder = r"C:\Users\prana\OneDrive\Desktop\Dataset sorted\YOLO Dataset\Data\images\train" # Folder containing images
# text_folder = r"C:\Users\prana\OneDrive\Desktop\Dataset sorted\YOLO Dataset\Data\labels\train"      # Folder containing text files

# # Get list of all text file names (without extension)
# text_files = {os.path.splitext(f)[0] for f in os.listdir(text_folder) if f.endswith(".txt")}

# # Process images
# for image in os.listdir(images_folder):
#     if image.endswith((".jpg", ".png")):  # Modify for other image formats if needed
#         image_name = os.path.splitext(image)[0]  # Get image name without extension
        
#         if image_name not in text_files:  # If no matching text file found
#             image_path = os.path.join(images_folder, image)
#             os.remove(image_path)  # Delete the image
#             print(f"Deleted: {image}")  # Log deleted images

# print("Cleanup complete! Images without matching text files have been removed.")








import os

# Define path to the folder containing text files
text_folder = r"C:\Users\prana\OneDrive\Desktop\Dataset sorted\YOLO Dataset\Data\labels\train"  # Change this to your actual folder path

# Iterate through the text files in sorted order
for filename in sorted(os.listdir(text_folder)):  # Sorting ensures a consistent first match
    if filename.endswith(".txt"):  # Process only text files
        file_path = os.path.join(text_folder, filename)
        
        # Read the first value of the first line
        with open(file_path, "r") as file:
            first_line = file.readline().strip()  # Read first line and remove whitespace
            first_value = first_line.split()[0] if first_line else None  # Extract first value
            
            if first_value == "2":  # Check if it's 2
                print(f"First file with first value as 2: {filename}")
                break  # Stop after finding the first matching file

print("Search complete.")
