# from flask import Flask, request, jsonify
# import tensorflow as tf
# from PIL import Image
# import io
# import numpy as np
# from flask_cors import CORS


# app = Flask(__name__)
# CORS(app)  # Allow cross-origin requests

# # Load your TFLite model
# interpreter = tf.lite.Interpreter(model_path=r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best_float32 (2).tflite")
# interpreter.allocate_tensors()

# # Get input and output details from the TFLite model
# input_details = interpreter.get_input_details()
# output_details = interpreter.get_output_details()

# def preprocess_image(image_bytes):
#     image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
#     image = image.resize((224, 224))  # Resize to the input size of the model
#     image_array = np.array(image, dtype=np.float32)
#     image_array = np.expand_dims(image_array, axis=0)  # Add batch dimension
#     image_array = image_array / 255.0  # Normalize the image
#     return image_array

# @app.route('/yolov8', methods=['POST'])
# def upload_file():
#     if 'file' not in request.files:
#         return jsonify({"error": "No file part"}), 400

#     file = request.files['file']
#     if file.filename == '':
#         return jsonify({"error": "No selected file"}), 400

#     # Read the image file and preprocess it
#     image_bytes = file.read()
#     image_array = preprocess_image(image_bytes)

#     # Set the input tensor to the preprocessed image
#     interpreter.set_tensor(input_details[0]['index'], image_array)

#     # Run the model
#     interpreter.invoke()

#     # Get the output
#     output_data = interpreter.get_tensor(output_details[0]['index'])
#     detections = output_data[0]

#     # Format the output (this will vary based on your model)
#     results = []
#     for detection in detections:
#         results.append({
#             "class": int(detection[0]),  # Assuming the class is in index 0
#             "confidence": float(detection[1]),  # Assuming confidence is in index 1
#             "bbox": detection[2:6].tolist()  # Assuming bounding box is in the next 4 indices
#         })

#     return jsonify({"detections": results})

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5001)
from flask import Flask, request, jsonify
import numpy as np
from PIL import Image
import tensorflow as tf
from io import BytesIO

app = Flask(__name__)

# Load your TFLite model
interpreter = tf.lite.Interpreter(model_path=r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best_float32 (2).tflite")
interpreter.allocate_tensors()

# Get model input details
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

@app.route('/yolov8', methods=['POST'])
def detect_objects():
    try:
        # Check if the image is in the request
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400

        # Open the image
        image = Image.open(file.stream)

        # Resize the image to match model input size (640x640)
        image = image.resize((640, 640))  # Resize to 640x640

        # Convert image to numpy array and normalize if necessary
        image_np = np.array(image).astype(np.float32)

        # Check for RGB or BGR and normalize accordingly
        image_np = image_np / 255.0  # Normalize to [0, 1]

        # If the model expects a batch dimension, add it
        image_np = np.expand_dims(image_np, axis=0)

        # Make sure the image has the right shape for the model (e.g., (1, 640, 640, 3) for RGB)
        if len(image_np.shape) == 3:  # For single images without batch size
            image_np = np.expand_dims(image_np, axis=0)  # Add batch dimension

        # Run inference on the model
        interpreter.set_tensor(input_details[0]['index'], image_np)
        interpreter.invoke()

        # Get the output from the model
        output_data = interpreter.get_tensor(output_details[0]['index'])

        # Process the output data (This part depends on your model's output format)
        detections = process_output(output_data)  # Implement this function based on your output

        return jsonify({"detections": detections})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Function to process the output (you need to define this based on your model's output format)
def process_output(output_data):
    # Example: For object detection models, process bounding boxes, class labels, and confidence scores
    detections = []
    for detection in output_data[0]:  # Assuming output_data contains detections
        # Example format of detection:
        # [class_id, confidence, xmin, ymin, xmax, ymax]
        detection_dict = {
            "class_id": int(detection[0]),
            "confidence": float(detection[1]),
            "bbox": {
                "xmin": float(detection[2]),
                "ymin": float(detection[3]),
                "xmax": float(detection[4]),
                "ymax": float(detection[5])
            }
        }
        detections.append(detection_dict)
    
    return detections

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
