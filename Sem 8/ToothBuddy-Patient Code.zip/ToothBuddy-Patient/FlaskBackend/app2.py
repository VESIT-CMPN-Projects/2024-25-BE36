from ultralytics import YOLO
import cv2

# Load the YOLOv8 model
model_path = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best_float32 (2).tflite"
model = YOLO(model_path)

# Load an image
image_path = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\6.jpg"  # Replace with the path to your test image
image = cv2.imread(image_path)

# Run inference
results = model(image)

# Draw bounding boxes
for result in results:
    for box in result.boxes.xyxy.cpu().numpy():
        x1, y1, x2, y2 = map(int, box)  # Get coordinates
        cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)  # Draw box

# Save and display result
cv2.imwrite("output.jpg", image)
cv2.imshow("Detection", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
# from ultralytics import YOLO
# import cv2

# # Load the YOLOv8 model
# model_path = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best (1).pt"
# model = YOLO(model_path)

# # Load an image
# image_path = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\nottooth.png"  # Replace with the path to your test image
# image = cv2.imread(image_path)

# # Run inference with a confidence threshold
# threshold = 0.5  # Set your desired confidence threshold
# results = model(image, conf=threshold)  # Apply confidence filtering

# # Draw bounding boxes
# for result in results:
#     for box, conf in zip(result.boxes.xyxy.cpu().numpy(), result.boxes.conf.cpu().numpy()):
#         if conf >= threshold:  # Apply confidence threshold
#             x1, y1, x2, y2 = map(int, box)  # Get coordinates
#             cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)  # Draw box
#             label = f"{conf:.2f}"  # Format confidence score
#             cv2.putText(image, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

# # Save and display result
# print(conf)
# cv2.imwrite("output.jpg", image)
# cv2.imshow("Detection", image)
# cv2.waitKey(0)
# cv2.destroyAllWindows()







# from flask import Flask, request, jsonify
# from ultralytics import YOLO
# import torch
# from PIL import Image
# import io

# app = Flask(__name__)

# # Load the YOLO model
# model = YOLO(r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best (2).pt")

# def predict_image(image):
#     results = model(image)
#     detections = []
#     for result in results:
#         for box in result.boxes:
#             x1, y1, x2, y2 = box.xyxy[0].tolist()  # Bounding box coordinates
#             conf = float(box.conf[0])  # Confidence score
#             cls = int(box.cls[0])  # Class index
#             detections.append({
#                 "x1": x1,
#                 "y1": y1,
#                 "x2": x2,
#                 "y2": y2,
#                 "confidence": conf,
#                 "class": model.names[cls]  # Convert class index to name
#             })
#     return detections

# @app.route("/predict", methods=["POST"])
# def predict():
#     if "image" not in request.files:
#         return jsonify({"error": "No image uploaded"}), 400
    
#     image_file = request.files["image"]
#     image = Image.open(io.BytesIO(image_file.read()))
    
#     detections = predict_image(image)
#     return jsonify({"detections": detections})

# if __name__ == "__main__":
#     app.run(debug=True)
