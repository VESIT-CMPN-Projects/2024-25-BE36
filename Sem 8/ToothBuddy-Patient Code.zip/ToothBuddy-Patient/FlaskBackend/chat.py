from flask import Flask, request, jsonify
from flask_cors import CORS
import google.generativeai as genai
import os

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})  # Allows frontend to communicate with backend

# Set up the Gemini API key
GEMINI_API_KEY = "AIzaSyDgX-cjhF942gPSLmrVR742thetZeJjC4M"  # Replace with your actual API key
genai.configure(api_key=GEMINI_API_KEY)

# Define a prompt for the chatbot
PROMPT = """
You are a highly knowledgeable dental chatbot. You assist users with dental issues, provide oral health advice, 
and answer general dental-related queries in a professional and friendly manner.Do not answer anything other than that if it other than a dental 
related question and also if the user asks such question then just say that it is out of your scope. Make sure that you keep the length of the response very precise and sufficient
as the user will be on the phone.
"""

@app.route("/chat", methods=["POST"])
def chat():
    try:
        # Get user message from frontend
        data = request.json
        user_message = data.get("message", "")

        if not user_message:
            return jsonify({"error": "Message is required"}), 400

        # Use Gemini API to generate a response
        model = genai.GenerativeModel("gemini-1.5-pro")
        response = model.generate_content(PROMPT + "\nUser: " + user_message + "\nChatbot:")
        print(response)
        # Send the chatbot's response to the frontend
        return jsonify({"response": response.text})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True,host="0.0.0.0",port=5001)
