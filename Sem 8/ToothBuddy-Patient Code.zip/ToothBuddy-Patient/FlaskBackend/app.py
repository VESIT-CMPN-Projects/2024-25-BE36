# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import numpy as np
# from PIL import Image
# import tensorflow as tf
# import logging

# app = Flask(__name__)
# CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all routes

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Load your YOLO TFLite model
# interpreter = tf.lite.Interpreter(model_path=r'C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best_float16 (1).tflite')
# interpreter.allocate_tensors()

# # Get input and output details
# input_details = interpreter.get_input_details()
# output_details = interpreter.get_output_details()

# # Load class labels from labels.txt   "C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\labels.txt"
# with open(r'C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\labels.txt', 'r') as f:
#     labels = [line.strip() for line in f.readlines()]

# @app.route('/')
# def home():
#     return "Welcome to the YOLO Detection API!"

# @app.route('/detect', methods=['POST'])
# def detect_objects():
#     app.logger.info("Received a request at /detect endpoint")

#     if 'file' not in request.files:
#         app.logger.error("No file part in the request")
#         return jsonify({"error": "No file part"}), 400

#     file = request.files['file']
#     if file.filename == '':
#         app.logger.error("No selected file")
#         return jsonify({"error": "No selected file"}), 400

#     try:
#         # Process the image
#         img = Image.open(file).convert('RGB')  # Ensure image is in RGB format
#         img = img.resize((736, 736))  # Adjust size according to your YOLO model input size
#         img_array = np.array(img, dtype=np.float32) / 255.0  # Normalize the image
#         img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension

#         # Set the tensor for input
#         interpreter.set_tensor(input_details[0]['index'], img_array)

#         # Run inference
#         interpreter.invoke()

#         # Get the output
#         output_data = interpreter.get_tensor(output_details[0]['index'])
        
#         # Log the raw output data for debugging
#         app.logger.info(f"Raw output data: {output_data}")

#         # Process the output data to extract detections
#         detections = []
#         for i in range(len(output_data[0])):
#             # Assuming output format: [class_id, confidence, x_min, y_min, x_max, y_max]
#             # Adjust indices based on your model's output structure
#             scores = output_data[0][i][:len(labels)]  # Get class scores
#             class_id = int(np.argmax(scores))  # Find the index of the highest score (class ID)
#             confidence = float(np.max(scores))  # Use the highest score as the confidence
#             bbox = output_data[0][i][len(labels):len(labels)+4].tolist()  # Extract bounding box coordinates

#             # Map class ID to label
#             label = labels[class_id] if class_id < len(labels) else "unknown"

#             # Filter out low-confidence detections
#             if confidence > 0.0005:  # Adjust this threshold as needed
#                 detections.append({"label": label, "confidence": confidence, "box": bbox})
#                 app.logger.info(f"Detection {i}: label={label}, confidence={confidence}, bbox={bbox}")

#         app.logger.info(f"Detections: {detections}")

#         return jsonify({"detections": detections})

#     except Exception as e:
#         app.logger.error(f"Error processing the image: {e}")
#         return jsonify({"error": "Error processing the image"}), 500

# if __name__ == '__main__':
#     app.logger.info("Starting Flask server...")
#     app.run(host="0.0.0.0", port=5000, debug=True)  # Run on 0.0.0.0 to allow external access




# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import torch
# import logging
# from PIL import Image
# import numpy as np
# from ultralytics import YOLO

# app = Flask(__name__)
# CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all routes

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Load the YOLOv8 model
# MODEL_PATH = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best (1) tD.pt"
# model = YOLO(MODEL_PATH)

# # Load class labels
# LABELS_PATH = r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\labels.txt"
# with open(LABELS_PATH, 'r') as f:
#     labels = [line.strip() for line in f.readlines()]

# @app.route('/')
# def home():
#     return "Welcome to the YOLOv8 Detection API!"

# @app.route('/detect', methods=['POST'])
# def detect_objects():
#     app.logger.info("Received a request at /detect endpoint")

#     if 'file' not in request.files:
#         app.logger.error("No file part in the request")
#         return jsonify({"error": "No file part"}), 400

#     file = request.files['file']
#     if file.filename == '':
#         app.logger.error("No selected file")
#         return jsonify({"error": "No selected file"}), 400

#     try:
#         # Load and preprocess the image
#         img = Image.open(file).convert('RGB')
        
#         # Run YOLOv8 inference
#         results = model(img, conf=0.3)  # Set confidence threshold to 0.3 (adjustable)

#         detections = []
#         for result in results:
#             boxes = result.boxes.xyxy.cpu().numpy()  # Bounding boxes (x_min, y_min, x_max, y_max)
#             scores = result.boxes.conf.cpu().numpy()  # Confidence scores
#             class_ids = result.boxes.cls.cpu().numpy().astype(int)  # Class IDs

#             for i in range(len(boxes)):
#                 label = labels[class_ids[i]] if class_ids[i] < len(labels) else "unknown"
#                 detections.append({
#                     "label": label,
#                     "confidence": float(scores[i]),
#                     "box": boxes[i].tolist()
#                 })

#         app.logger.info(f"Detections: {detections}")

#         return jsonify({"detections": detections})

#     except Exception as e:
#         app.logger.error(f"Error processing the image: {e}")
#         return jsonify({"error": "Error processing the image"}), 500

# if __name__ == '__main__':
#     app.logger.info("Starting Flask server...")
#     app.run(host="0.0.0.0", port=5000, debug=True)

###-------------------------------------------------------------------------------------------------------------







# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from inference_sdk import InferenceHTTPClient
# import logging
# import os

# app = Flask(__name__)
# CORS(app, resources={r"/*": {"origins": "*"}})  # Enable CORS for all routes

# # Configure logging
# logging.basicConfig(level=logging.DEBUG)

# # Initialize Roboflow Inference Client
# CLIENT = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="23Hl2N7VNYHcMriNrrEa"
# )
# MODEL_ID = "oral-diseases-5ctay/1"

# @app.route('/')
# def home():
#     return "Welcome to the ToothBuddy Detection API using Roboflow!"

# @app.route('/detect', methods=['POST'])
# def detect_objects():
#     app.logger.info("Received a request at /detect endpoint")
    
#     if 'file' not in request.files:
#         app.logger.error("No file part in the request")
#         return jsonify({"error": "No file part"}), 400
    
#     file = request.files['file']
#     if file.filename == '':
#         app.logger.error("No selected file")
#         return jsonify({"error": "No selected file"}), 400
    
#     try:
#         # Save the image temporarily
#         temp_path = "temp_image.jpg"
#         file.save(temp_path)
        
#         # Send image to Roboflow for inference
#         result = CLIENT.infer(temp_path, model_id=MODEL_ID)
        
#         # Clean up temporary file
#         os.remove(temp_path)
        
#         return jsonify(result)
    
#     except Exception as e:
#         app.logger.error(f"Error processing the image: {e}")
#         return jsonify({"error": "Error processing the image"}), 500

# if __name__ == '__main__':
#     app.logger.info("Starting Flask server...")
#     app.run(host="0.0.0.0", port=5000, debug=True)


# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from inference_sdk import InferenceHTTPClient
# import logging

# app = Flask(__name__)
# CORS(app, resources={r"/*": {"origins": "*"}})

# logging.basicConfig(level=logging.DEBUG)

# CLIENT = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="23Hl2N7VNYHcMriNrrEa"
# )
# MODEL_ID = "oral-diseases-5ctay/1"

# @app.route('/')
# def home():
#     return "Welcome to the ToothBuddy Detection API using Roboflow!"

# @app.route('/detect', methods=['POST'])
# def detect_objects():
#     app.logger.info("Received a request at /detect endpoint")

#     if 'file' not in request.files:
#         return jsonify({"error": "No file uploaded"}), 400

#     file = request.files['file']

#     try:
#         # Send image directly to Roboflow
#         result = CLIENT.infer(file.read(), model_id=MODEL_ID)
#         return jsonify(result)

#     except Exception as e:
#         app.logger.error(f"Error processing image: {e}")
#         return jsonify({"error": "Processing failed"}), 500

# if __name__ == '__main__':
#     app.run(host="0.0.0.0", port=5000, debug=True)



# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from inference_sdk import InferenceHTTPClient
# import logging
# import tempfile

# app = Flask(__name__)
# CORS(app, resources={r"/*": {"origins": "*"}})

# logging.basicConfig(level=logging.DEBUG)

# CLIENT = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="GXY6ZJTCRnW4cSjU4Oc1"
# )
# MODEL_ID = "tooth-diseases-0ocji/1"

# @app.route('/')
# def home():
#     return "Welcome to the ToothBuddy Detection API using Roboflow!"

# @app.route('/detect', methods=['POST'])
# def detect_objects():
#     app.logger.info("Received a request at /detect endpoint")

#     if 'file' not in request.files:
#         return jsonify({"error": "No file uploaded"}), 400

#     file = request.files['file']

#     try:
#         # Save the uploaded image temporarily
#         with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as temp_file:
#             file.save(temp_file.name)  # Save the image to a file
#             temp_file_path = temp_file.name

#         # Send the file path to Roboflow
#         result = CLIENT.infer(temp_file_path, model_id=MODEL_ID)

#         return jsonify(result)

#     except Exception as e:
#         app.logger.error(f"Error processing image: {e}")
#         return jsonify({"error": "Processing failed"}), 500

# if __name__ == '__main__':
#     app.run(host="0.0.0.0", port=5000, debug=True)

# from flask import Flask, request, jsonify
# from inference_sdk import InferenceHTTPClient
# import os

# app = Flask(__name__)

# # Allow cross-origin requests (for mobile app integration)
# from flask_cors import CORS
# CORS(app)

# # Roboflow client setup
# client = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="GXY6ZJTCRnW4cSjU4Oc1"
# )

# @app.route('/predict', methods=['POST'])
# def predict():
#     if 'image' not in request.files:
#         return jsonify({'error': 'No image uploaded'}), 400
    
#     image_file = request.files['image']
#     image_path = "temp.jpg"
#     image_file.save(image_path)  # Save temporarily

#     # Send image to Roboflow
#     result = client.run_workflow(
#         workspace_name="teminiproj",
#         workflow_id="custom-workflow",
#         images={"image": image_path},
#         use_cache=True
#     )

#     # Remove temp file
#     os.remove(image_path)

#     return jsonify(result)

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)





# from flask import Flask, request, jsonify
# from inference_sdk import InferenceHTTPClient
# import os
# import base64

# app = Flask(__name__)

# # Allow cross-origin requests (for mobile app integration)
# from flask_cors import CORS
# CORS(app)

# # Roboflow client setup
# client = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="GXY6ZJTCRnW4cSjU4Oc1"
# )

# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         data = request.get_json()
        
#         if not data or 'image' not in data:
#             return jsonify({'error': 'No image provided'}), 400

#         # Decode Base64 image
#         image_data = base64.b64decode(data['image'])
#         image_path = "temp.jpg"

#         with open(image_path, "wb") as f:
#             f.write(image_data)

#         # Send image to Roboflow
#         result = client.run_workflow(
#             workspace_name="teminiproj",
#             workflow_id="custom-workflow",
#             images={"image": image_path},
#             use_cache=True
#         )

#         # Remove temp file
#         os.remove(image_path)

#         return jsonify(result)

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)






# from flask import Flask, request, jsonify
# from inference_sdk import InferenceHTTPClient
# import os
# import base64
# import tensorflow.lite as tflite
# import numpy as np
# from PIL import Image
# import io

# app = Flask(__name__)

# # Allow cross-origin requests (for mobile app integration)
# from flask_cors import CORS
# CORS(app)

# # Roboflow client setup
# client = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="GXY6ZJTCRnW4cSjU4Oc1"
# )

# # Load the TFLite model
# interpreter = tflite.Interpreter(model_path=r"C:\Users\prana\OneDrive\Desktop\vscodes\New folder\FlaskBackend\Models\best_float32 (2).tflite")
# interpreter.allocate_tensors()

# # Get input and output details
# input_details = interpreter.get_input_details()
# output_details = interpreter.get_output_details()

# # Function to preprocess image
# def preprocess_image(image):
#     image = image.resize((input_details[0]['shape'][1], input_details[0]['shape'][2]))
#     image = np.array(image, dtype=np.float32) / 255.0  # Normalize
#     image = np.expand_dims(image, axis=0)  # Add batch dimension
#     return image

# # Function to perform inference
# def predict_image(image):
#     image = preprocess_image(image)
#     interpreter.set_tensor(input_details[0]['index'], image)
#     interpreter.invoke()
#     output_data = interpreter.get_tensor(output_details[0]['index'])
#     return output_data.tolist()

# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         data = request.get_json()
        
#         if not data or 'image' not in data:
#             return jsonify({'error': 'No image provided'}), 400

#         # Decode Base64 image
#         image_data = base64.b64decode(data['image'])
#         image_path = "temp.jpg"

#         with open(image_path, "wb") as f:
#             f.write(image_data)

#         # Send image to Roboflow
#         result = client.run_workflow(
#             workspace_name="teminiproj",
#             workflow_id="custom-workflow",
#             images={"image": image_path},
#             use_cache=True
#         )

#         # Remove temp file
#         os.remove(image_path)

#         return jsonify(result)

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/yolov8', methods=['POST'])
# def yolov8():
#     try:
#         if "image" not in request.files:
#             return jsonify({"error": "No image uploaded"}), 400
        
#         image_file = request.files["image"]
#         image = Image.open(io.BytesIO(image_file.read())).convert("RGB")
        
#         predictions = predict_image(image)
#         return jsonify({"predictions": predictions})

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)








# from flask import Flask, request, jsonify
# from inference_sdk import InferenceHTTPClient
# import os
# import tensorflow.lite as tflite
# import numpy as np
# from PIL import Image
# import io

# app = Flask(__name__)

# # Allow cross-origin requests (for mobile app integration)
# from flask_cors import CORS
# CORS(app)

# # Roboflow client setup
# client = InferenceHTTPClient(
#     api_url="https://detect.roboflow.com",
#     api_key="GXY6ZJTCRnW4cSjU4Oc1"
# )
# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         if "file" not in request.files:
#             return jsonify({"error": "No image uploaded"}), 400

#         image_file = request.files["file"]
#         image = Image.open(io.BytesIO(image_file.read())).convert("RGB")
        
#         # Send image to Roboflow
#         result = client.run_workflow(
#             workspace_name="teminiproj",
#             workflow_id="custom-workflow",
#             images={"image": image},
#             use_cache=True
#         )

#         return jsonify(result)

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True, host='0.0.0.0', port=5000)

from flask import Flask, request, jsonify
from inference_sdk import InferenceHTTPClient
import base64
import io
from PIL import Image
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Roboflow client setup
client = InferenceHTTPClient(
    api_url="https://detect.roboflow.com",
    api_key="GXY6ZJTCRnW4cSjU4Oc1"
)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()

        if "image" not in data:
            return jsonify({"error": "No image data received"}), 400

        # Decode base64 image
        image_data = base64.b64decode(data["image"])
        image = Image.open(io.BytesIO(image_data)).convert("RGB")

        # Send image to Roboflow
        result = client.run_workflow(
            workspace_name="teminiproj",
            workflow_id="custom-workflow",
            images={"image": image},
            use_cache=True
        )

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
