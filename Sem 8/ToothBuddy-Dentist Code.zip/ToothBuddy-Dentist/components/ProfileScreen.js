import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, ActivityIndicator, Image, TouchableOpacity } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { auth, db } from "../firebaseConfig";
import { collection, query, where, getDocs, updateDoc } from "firebase/firestore";

const CLOUDINARY_URL = "https://api.cloudinary.com/v1_1/dzsrg1xlh/image/upload";
const UPLOAD_PRESET = "profile_image"; // Replace with your actual Cloudinary preset

const ProfileScreen = () => {
  const [dentist, setDentist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imageUrl, setImageUrl] = useState(null); // Profile image state

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const dentistEmail = auth.currentUser?.email;
        if (!dentistEmail) {
          console.log("No logged-in dentist email found!");
          setLoading(false);
          return;
        }

        console.log("Current Dentist Email:", dentistEmail);
        const q = query(collection(db, "dentists"), where("email", "==", dentistEmail));
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
          const userData = snapshot.docs[0].data();
          setDentist(userData);
          setImageUrl(userData.profileImage || null); // Load profile image if exists
        } else {
          console.log("No dentist found with the given email!");
        }
      } catch (error) {
        console.error("Error fetching dentist details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const uploadImage = async () => {
    // Request media library permissions
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (status !== "granted") {
      alert("Permission to access gallery is required!");
      return;
    }
  
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // Fix deprecated API
      allowsEditing: true,
      quality: 1,
    });
  
    if (!result.canceled) {
      const imageUri = result.assets[0].uri;
  
      let data = new FormData();
      data.append("file", { uri: imageUri, type: "image/jpeg", name: "profile.jpg" });
      data.append("upload_preset", UPLOAD_PRESET);
  
      try {
        const response = await fetch(CLOUDINARY_URL, {
          method: "POST",
          body: data,
          headers: { "Content-Type": "multipart/form-data" },
        });
  
        const resultData = await response.json();
        console.log("Cloudinary Response:", resultData);
  
        if (resultData.secure_url) {
          setImageUrl(resultData.secure_url);
  
          // Save image URL in Firestore
          const dentistEmail = auth.currentUser?.email;
          if (dentistEmail) {
            const q = query(collection(db, "dentists"), where("email", "==", dentistEmail));
            const snapshot = await getDocs(q);
  
            if (!snapshot.empty) {
              const userDoc = snapshot.docs[0].ref;
              await updateDoc(userDoc, { profileImage: resultData.secure_url });
              console.log("Image URL saved in Firestore");
            }
          }
        }
      } catch (error) {
        console.error("❌ Upload error:", error);
      }
    }
  };
  

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  if (!dentist) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>No profile found!</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.header}>Dentist Profile</Text>
        <View style={styles.divider} />

        {/* Profile Image */}
        <Image
          source={{ uri: imageUrl || "https://via.placeholder.com/150" }} // Placeholder if no image
          style={styles.profileImage}
        />

        {/* Upload Image Button */}
        <TouchableOpacity style={styles.uploadButton} onPress={uploadImage}>
          <Text style={styles.uploadText}>Upload Image</Text>
        </TouchableOpacity>

        <Text style={styles.detail}><Text style={styles.label}>Name:</Text> {dentist.name.trim()}</Text>
        <Text style={styles.detail}><Text style={styles.label}>Email:</Text> {dentist.email}</Text>
        <Text style={styles.detail}><Text style={styles.label}>Phone:</Text> {dentist.phone}</Text>
        <Text style={styles.detail}><Text style={styles.label}>Location:</Text> {dentist.location.trim()}</Text>
        <Text style={styles.detail}><Text style={styles.label}>Experience:</Text> {dentist.experience} years</Text>
        <Text style={styles.detail}><Text style={styles.label}>Specialization:</Text> {dentist.specialization.trim()}</Text>
        <Text style={styles.detail}><Text style={styles.label}>Availability:</Text> {dentist.time}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F0F8FF",
    padding: 20,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 15,
    padding: 25,
    width: "90%",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
    alignItems: "center",
  },
  header: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#007AFF",
    marginBottom: 15,
  },
  divider: {
    height: 3,
    backgroundColor: "#007AFF",
    width: "100%",
    marginBottom: 15,
    borderRadius: 2,
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 2,
    borderColor: "#007AFF",
    marginBottom: 10,
  },
  uploadButton: {
    backgroundColor: "#007AFF",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  uploadText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  detail: {
    fontSize: 18,
    marginBottom: 12,
    color: "#333",
  },
  label: {
    fontWeight: "bold",
    color: "#007AFF",
  },
  loadingText: {
    fontSize: 18,
    textAlign: "center",
    marginTop: 10,
    color: "#007AFF",
  },
  errorText: {
    fontSize: 18,
    textAlign: "center",
    color: "red",
  },
});

export default ProfileScreen;
