import React, { useState } from "react";
import { View, StyleSheet, Image } from "react-native";
import { TextInput, Button, Card, Title } from "react-native-paper";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { setDoc, doc } from "firebase/firestore";
import { auth, db } from "../firebaseConfig";

const AuthScreen = ({ navigation, isRegister }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [experience, setExperience] = useState("");
  const [location, setLocation] = useState("");

  const handleAuth = async () => {
    try {
      if (isRegister) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        await setDoc(doc(db, "dentists", user.uid), {
          name,
          email,
          phone,
          specialization,
          experience,
          location,
          time: "17:00 hrs to 20:30 hrs",
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      navigation.navigate("HomeScreen");
    } catch (error) {
      console.error("Error:", error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: "https://via.placeholder.com/150" }} style={styles.logo} />

      <Card style={styles.card}>
        <Card.Content>
          <Title style={styles.title}>{isRegister ? "Register" : "Login"}</Title>
          {isRegister && (
            <>
              <TextInput label="Name" value={name} onChangeText={setName} style={styles.input} />
              <TextInput label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" style={styles.input} />
              <TextInput label="Specialization" value={specialization} onChangeText={setSpecialization} style={styles.input} />
              <TextInput label="Experience" value={experience} onChangeText={setExperience} keyboardType="numeric" style={styles.input} />
              <TextInput label="Location" value={location} onChangeText={setLocation} style={styles.input} />
            </>
          )}
          <TextInput label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" style={styles.input} />
          <TextInput label="Password" value={password} onChangeText={setPassword} secureTextEntry style={styles.input} />
          <Button mode="contained" onPress={handleAuth} style={styles.button}>
            {isRegister ? "Register" : "Login"}
          </Button>
          <Button mode="text" onPress={() => navigation.navigate(isRegister ? "Login" : "Register")}>
            {isRegister ? "Already have an account? Login" : "Don't have an account? Register"}
          </Button>
        </Card.Content>
      </Card>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#EAF6FF", padding: 20 },
  logo: { width: 120, height: 120, marginBottom: 20 },
  card: { width: "100%", padding: 20, borderRadius: 10, backgroundColor: "#ffffff", elevation: 5 },
  title: { textAlign: "center", fontSize: 22, fontWeight: "bold", marginBottom: 10 },
  input: { marginBottom: 12 },
  button: { marginTop: 12, backgroundColor: "#0097e6" },
});

export const RegisterScreen = (props) => <AuthScreen {...props} isRegister={true} />;
export const LoginScreen = (props) => <AuthScreen {...props} isRegister={false} />;