import React, { useState, useEffect, useCallback, useLayoutEffect } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { auth, db } from "../firebaseConfig";
import { collection, query, where, getDocs } from "firebase/firestore";

const HomeScreen = ({ navigation }) => {
  const [dentist, setDentist] = useState({ name: "Dentist", id: null, profileImage: null });
  const [appointments, setAppointments] = useState([]);
  const [chats, setChats] = useState([]);
  const [activeTab, setActiveTab] = useState("appointments");

  const fetchDentistInfo = async () => {
    const dentistEmail = auth.currentUser?.email;
    if (!dentistEmail) return;
    try {
      const q = query(collection(db, "dentists"), where("email", "==", dentistEmail));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const dentistData = snapshot.docs[0].data();
        setDentist({
          name: dentistData.name || "Dentist",
          id: snapshot.docs[0].id,
          profileImage: dentistData.profileImage || "https://via.placeholder.com/150",
        });
      }
    } catch (error) {
      console.error("Error fetching dentist info:", error);
    }
  };

  const fetchAppointments = async () => {
    if (!dentist.id) return;
    try {
      const appointmentsRef = collection(db, "dentists", dentist.id, "appointments");
      const snapshot = await getDocs(appointmentsRef);
      setAppointments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      console.error("Error fetching appointments:", error);
    }
  };

  const fetchChats = async () => {
    const dentistEmail = auth.currentUser?.email;
    if (!dentistEmail) return;
    try {
      const chatsRef = collection(db, "chats");
      const snapshot = await getDocs(chatsRef);
      const dentistChats = snapshot.docs.filter(doc => doc.id.startsWith(dentistEmail + "_"))
        .map(doc => ({ id: doc.id, ...doc.data() }));
      setChats(dentistChats);
    } catch (error) {
      console.error("Error fetching chats:", error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchDentistInfo();
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      if (dentist.id) {
        fetchAppointments();
        fetchChats();
      }
    }, [dentist.id])
  );

  useLayoutEffect(() => {
    navigation.setOptions({
      title: `Welcome, ${dentist.name}`,
      headerStyle: { backgroundColor: "#0097e6" },
      headerTitleStyle: { color: "white", fontSize: 20, fontWeight: "bold" },
      headerRight: () => (
        <TouchableOpacity onPress={() => navigation.navigate("ProfileScreen")} style={{ marginRight: 15 }}>
          <Image
            source={{ uri: dentist.profileImage }}
            style={{ width: 35, height: 35, borderRadius: 17.5, borderWidth: 1, borderColor: "white" }}
          />
        </TouchableOpacity>
      ),
    });
  }, [navigation, dentist]);

  const renderTabs = () => (
    <View style={styles.tabsContainer}>
      <TouchableOpacity
        style={[styles.tab, activeTab === "appointments" && styles.activeTab]}
        onPress={() => setActiveTab("appointments")}
      >
        <Text style={[styles.tabText, activeTab === "appointments" && styles.activeTabText]}>Appointments</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, activeTab === "consultations" && styles.activeTab]}
        onPress={() => setActiveTab("consultations")}
      >
        <Text style={[styles.tabText, activeTab === "consultations" && styles.activeTabText]}>Online Consultations</Text>
      </TouchableOpacity>
    </View>
  );

  const renderAppointment = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{item.Name}</Text>
      <Text style={styles.cardSubtitle}>{item.appointmentDate} {item.time}</Text>
      <TouchableOpacity
        style={styles.reportButton}
        onPress={() => navigation.navigate("ReportScreen", { userId: item.userId })}
      >
        <Text style={styles.buttonText}>View Report</Text>
      </TouchableOpacity>
    </View>
  );

  const renderChat = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Chat with {item.user1}</Text>
      <TouchableOpacity
        style={styles.chatButton}
        onPress={() => navigation.navigate("ChatScreen", { doctorEmail: item.user2, userEmail: item.user1 })}
      >
        <Text style={styles.buttonText}>Open Chat</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {renderTabs()}
      {activeTab === "appointments" ? (
        <FlatList
          data={appointments}
          keyExtractor={(item) => item.id}
          renderItem={renderAppointment}
          ListEmptyComponent={<Text style={styles.noData}>No appointments found</Text>}
        />
      ) : (
        <FlatList
          data={chats}
          keyExtractor={(item) => item.id}
          renderItem={renderChat}
          ListEmptyComponent={<Text style={styles.noData}>No online consultations found</Text>}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#EAF6FF", paddingHorizontal: 20, paddingTop: 10 },
  tabsContainer: { flexDirection: "row", justifyContent: "space-around", backgroundColor: "#0097e6", borderRadius: 10, padding: 8, marginBottom: 15 },
  tab: { paddingVertical: 8, paddingHorizontal: 20, borderRadius: 10 },
  activeTab: { backgroundColor: "white" },
  tabText: { fontSize: 16, color: "white", fontWeight: "bold" },
  activeTabText: { color: "#0097e6" },
  card: { backgroundColor: "#fff", padding: 18, borderRadius: 12, marginBottom: 12 },
  cardTitle: { fontSize: 18, fontWeight: "600" },
  cardSubtitle: { fontSize: 16, marginTop: 4 },
  reportButton: { backgroundColor: "#2ecc71", padding: 10, borderRadius: 8, marginTop: 10, alignItems: "center" },
  chatButton: { backgroundColor: "#0097e6", padding: 10, borderRadius: 8, marginTop: 10, alignItems: "center" },
  buttonText: { color: "#fff", fontWeight: "bold" },
  noData: { fontSize: 18, color: "#777", textAlign: "center", marginTop: 30 },
});

export default HomeScreen;
