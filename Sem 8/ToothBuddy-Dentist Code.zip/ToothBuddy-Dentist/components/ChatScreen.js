import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Keyboard,
  TouchableWithoutFeedback,
  Linking,
} from "react-native";
import {
  collection,
  query,
  orderBy,
  addDoc,
  onSnapshot,
  serverTimestamp,
  doc,
  setDoc,
  getDoc,
} from "firebase/firestore";
import { db } from "../firebaseConfig";
import { getAuth } from "firebase/auth";
import { Ionicons } from "@expo/vector-icons";

const ChatScreen = ({ route }) => {
  const { userEmail, doctorEmail } = route.params || {};
  const auth = getAuth();
  const currentUser = auth.currentUser;
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef(null);

  if (!doctorEmail || !userEmail) {
    return (
      <View style={styles.errorContainer}>
        <Text>Error: Invalid Chat</Text>
      </View>
    );
  }

  const chatId =
    userEmail < doctorEmail
      ? `${userEmail}_${doctorEmail}`
      : `${doctorEmail}_${userEmail}`;

  useEffect(() => {
    if (!currentUser) return;
    const messagesRef = collection(db, "chats", chatId, "messages");
    const q = query(messagesRef, orderBy("timestamp", "asc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const loadedMessages = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMessages(loadedMessages);
        setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 300);
      }
    });
    return () => unsubscribe();
  }, [chatId, currentUser]);

  const ensureChatExists = async () => {
    try {
      const chatRef = doc(db, "chats", chatId);
      const chatDoc = await getDoc(chatRef);
      if (!chatDoc.exists()) {
        await setDoc(chatRef, {
          user1: userEmail,
          user2: doctorEmail,
          lastMessage: "",
          timestamp: serverTimestamp(),
        });
      }
    } catch (error) {
      console.error("Error ensuring chat exists:", error);
    }
  };

  const sendMessage = async () => {
    if (!currentUser || inputText.trim() === "") return;
    try {
      await ensureChatExists();
      await addDoc(collection(db, "chats", chatId, "messages"), {
        text: inputText,
        sender: currentUser.email,
        timestamp: serverTimestamp(),
      });
      setInputText("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const generateCallLink = () => `https://meet.jit.si/${chatId}`;

  const sendCallLink = async () => {
    if (!currentUser) return;
    try {
      const callLink = generateCallLink();
      await ensureChatExists();
      await addDoc(collection(db, "chats", chatId, "messages"), {
        text: callLink,
        sender: currentUser.email,
        timestamp: serverTimestamp(),
        type: "video_call",
      });
    } catch (error) {
      console.error("Error sending call link:", error);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 100 : 95}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.innerContainer}>
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View
                style={[
                  styles.messageContainer,
                  item.sender === currentUser?.email
                    ? styles.myMessage
                    : styles.otherMessage,
                ]}
              >
                {item.type === "video_call" || item.text.startsWith("https://") ? (
                  <TouchableOpacity onPress={() => Linking.openURL(item.text)}>
                    <Text style={[styles.messageText, styles.linkText]}>
                      {item.text}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  <Text
                    style={[
                      styles.messageText,
                      item.sender !== currentUser?.email && styles.otherMessageText,
                    ]}
                  >
                    {item.text}
                  </Text>
                )}
              </View>
            )}
            contentContainerStyle={{ paddingBottom: 80 }}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          />
        </View>
      </TouchableWithoutFeedback>
      <View style={styles.inputContainer}>
        <TouchableOpacity style={styles.callButton} onPress={sendCallLink}>
          <Ionicons name="videocam" size={24} color="white" />
        </TouchableOpacity>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          value={inputText}
          onChangeText={(text) => setInputText(text)}
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Ionicons name="send" size={24} color="white" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F8F9FA" },
  innerContainer: { flex: 1 },
  messageContainer: { padding: 10, margin: 5, borderRadius: 8, maxWidth: "75%" },
  myMessage: { alignSelf: "flex-end", backgroundColor: "#007BFF", borderRadius: 20, padding: 10 },
  otherMessage: { alignSelf: "flex-start", backgroundColor: "#E0E0E0", borderRadius: 20, padding: 10 },
  messageText: { fontSize: 16, color: "#fff" },
  otherMessageText: { color: "#000" },
  inputContainer: { flexDirection: "row", padding: 10, backgroundColor: "#fff", borderTopWidth: 1, borderColor: "#ddd", alignItems: "center" },
  input: { flex: 1, borderWidth: 1, borderColor: "#ccc", borderRadius: 20, padding: 10, fontSize: 16, backgroundColor: "#fff" },
  sendButton: { marginLeft: 10, backgroundColor: "#007BFF", padding: 12, borderRadius: 30 },
  callButton: { backgroundColor: "#007BFF", padding: 12, borderRadius: 30, marginRight: 10 },
  linkText: { color: "#000000", textDecorationLine: "underline" },
  
});

export default ChatScreen;
// inputContainer: {
//   flexDirection: "row",
//   padding: 10,
//   backgroundColor: "#fff",
//   borderTopWidth: 1,
//   borderColor: "#ddd",
//   alignItems: "center",
//   width: "100%",
//   paddingBottom: Platform.OS === "ios" ? 20 : 25, // Extra padding
// },
