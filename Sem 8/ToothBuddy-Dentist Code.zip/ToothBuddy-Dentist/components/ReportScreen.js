import React, { useEffect, useState } from "react";
import { View, Text, Image, ActivityIndicator, StyleSheet, ScrollView } from "react-native";
import { db } from "../firebaseConfig";
import { collection, query, where, getDocs } from "firebase/firestore";

const classMapping = {
  "1": "Ulcer",
  "2": "Tooth Discoloration",
  "3": "Gingivitis",
  "4": "Calculus",
  "caries": "Caries"
};

const ReportScreen = ({ route }) => {
  const { userId } = route.params;
  const [report, setReport] = useState(null);
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const usersRef = collection(db, "users");
        const userQuery = query(usersRef, where("email", "==", userId));
        const userSnapshot = await getDocs(userQuery);

        if (userSnapshot.empty) {
          console.log("No user found with this email");
          setLoading(false);
          return;
        }

        const userDoc = userSnapshot.docs[0];
        setUserInfo(userDoc.data());
        const userDocId = userDoc.id;

        const reportsRef = collection(db, "users", userDocId, "reports");
        const reportSnapshot = await getDocs(reportsRef);

        if (!reportSnapshot.empty) {
          const reports = reportSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          reports.sort((a, b) => new Date(b.date) - new Date(a.date));
          setReport(reports[0]);
        } else {
          setReport(null);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  if (loading) return <ActivityIndicator size="large" color="#0097e6" style={styles.loader} />;
  if (!userInfo) return <Text style={styles.noReport}>User not found</Text>;

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <Text style={styles.title}>User Profile</Text>

        <View style={styles.infoContainer}>
          <Text style={styles.infoText}>📛 Name: {userInfo.name}</Text>
          <Text style={styles.infoText}>✉️ Email: {userInfo.email}</Text>
          <Text style={styles.infoText}>⚧ Gender: {userInfo.gender}</Text>
          <Text style={styles.infoText}>🎂 DOB: {userInfo.dob}</Text>
          <Text style={styles.infoText}>📞 Phone: {userInfo.mobile}</Text>
          <Text style={styles.infoText}>🦷 Oral Problems: {userInfo.oralProblems}</Text>
        </View>

        <Text style={styles.title}>Latest Report</Text>
        {report ? (
          <View style={styles.reportContainer}>
            <Text style={styles.infoText}>📅 Date: {report.date}</Text>
            <Text style={styles.infoText}>Detected Issues:</Text>
            {report.imageUrl ? (
              <Image
                source={{ uri: report.imageUrl }}
                style={styles.reportImage}
                onError={(e) => console.log("Error loading report image:", e.nativeEvent.error)}
              />
            ) : (
              <Text style={styles.noReport}>No image available</Text>
            )}

{(report?.detections || []).map((detection, index) => (
  <Text key={index} style={styles.issueText}>
    🦷 {classMapping[detection.class] || "Unknown"} (Confidence: {(detection.confidence * 100).toFixed(2)}%)
  </Text>
))}
          </View>
        ) : (
          <Text style={styles.noReport}>No reports found</Text>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: { flexGrow: 1, paddingVertical: 20 },
  container: { flex: 1, padding: 20, backgroundColor: "#F9FAFB", alignItems: "center" },
  title: { fontSize: 26, fontWeight: "bold", marginBottom: 15, color: "#0288D1", textAlign: "center" },
  infoContainer: { width: "100%", backgroundColor: "#E3F2FD", padding: 15, borderRadius: 10, marginBottom: 20 },
  infoText: { fontSize: 18, color: "#333", marginBottom: 5 },
  reportContainer: { width: "100%", backgroundColor: "#FFF3E0", padding: 15, borderRadius: 10, marginBottom: 20 },
  issueText: { fontSize: 16, color: "#D84315", marginLeft: 10 },
  noReport: { fontSize: 18, color: "#666", textAlign: "center", marginTop: 20 },
  loader: { flex: 1, justifyContent: "center", alignItems: "center" },
  reportImage: {
    width: "100%", 
    height: 300, 
    resizeMode: "contain", 
    borderRadius: 10, 
    marginTop: 10, 
    borderWidth: 2, 
    borderColor: "#0288D1"
  }
});

export default ReportScreen;