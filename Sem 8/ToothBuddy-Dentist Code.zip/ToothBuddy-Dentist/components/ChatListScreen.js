import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from "react-native";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "../firebaseConfig";
import { getAuth } from "firebase/auth";

const ChatListScreen = ({ navigation }) => {
  const auth = getAuth();
  const currentUser = auth.currentUser;
  const [chats, setChats] = useState([]);

  useEffect(() => {
    if (!currentUser) return;
    const dentistEmail = currentUser.email;

    const chatsRef = collection(db, "chats");
    const q = query(chatsRef, where("user2", "==", dentistEmail));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chatList = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setChats(chatList);
    });

    return () => unsubscribe();
  }, [currentUser]);

  const openChat = (chat) => {
    navigation.navigate("ChatScreen", {
      doctorEmail: chat.user2, // Dentist email
      userEmail: chat.user1, // Patient email
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Chats</Text>
      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item)}>
            <Text style={styles.chatText}>Chat with {item.user1}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F9FA",
    padding: 10,
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  chatItem: {
    padding: 15,
    backgroundColor: "#E0E0E0",
    borderRadius: 8,
    marginBottom: 10,
  },
  chatText: {
    fontSize: 16,
    fontWeight: "500",
  },
});

export default ChatListScreen;