import { initializeApp } from "firebase/app";
import { getAuth, initializeAuth, getReactNativePersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: "AIzaSyDOcPkiy1fsShxLC_M_nIUkrydd_pwScVc",
  authDomain: "tb-user-9dca5.firebaseapp.com",
  projectId: "tb-user-9dca5",
  storageBucket: "tb-user-9dca5.appspot.com",
  messagingSenderId: "302260461564",
  appId: "1:302260461564:web:a9aa29413a43af8b019c79",
  measurementId: "G-ZESXPKVL89"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Use AsyncStorage for persistent auth state
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});

const db = getFirestore(app);

export { auth, db };
